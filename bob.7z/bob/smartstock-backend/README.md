# SmartStock Backend API

Backend server for Boystown Pharmacy SmartStock Management System.

## Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Database Setup
- Create MySQL database named `smartstock_db`
- Run the SQL scripts in `/database/schema.sql`
- Run the seed data in `/database/seed.sql`

### 3. Environment Configuration
- Copy `.env.example` to `.env`
- Update database credentials
- Change JWT_SECRET to a secure random string

### 4. Start Server
```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - Register new worker (Admin only)
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password
- `GET /api/auth/validate` - Validate JWT token

### Stock Management
- `GET /api/stock` - Get all stock items
- `POST /api/stock` - Add new stock item
- `PUT /api/stock/:id` - Update stock item
- `DELETE /api/stock/:id` - Delete stock item
- `POST /api/stock/import` - Bulk import from CSV

### Sales
- `GET /api/sales` - Get sales records
- `POST /api/sales` - Record new sale
- `GET /api/sales/report` - Generate sales report

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics
- `GET /api/dashboard/alerts` - Get low stock and expiry alerts

## Tech Stack
- Node.js & Express
- MySQL Database
- JWT Authentication
- bcrypt for password hashing
