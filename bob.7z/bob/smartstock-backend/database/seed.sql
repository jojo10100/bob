-- Seed Data for SmartStock Pharmacy
USE smartstock_db;

-- Insert Default Admin User
-- Password: Admin@123 (hashed with bcrypt)
INSERT INTO users (email, password, full_name, role, is_active) VALUES
('admin@boystown.com', '$2a$10$YourHashedPasswordHere', 'System Administrator', 'admin', TRUE);

-- Note: You'll need to update the password hash after running the app for the first time
-- Use the /api/auth/hash-password endpoint or bcrypt to generate the hash

-- Insert Default Categories
INSERT INTO categories (name, description) VALUES
('Antibiotics', 'Antibiotic medications'),
('Pain Relief', 'Pain relief and analgesics'),
('Vitamins', 'Vitamin supplements'),
('First Aid', 'First aid supplies'),
('Prescription', 'Prescription medications'),
('Over-the-Counter', 'OTC medications'),
('Medical Supplies', 'Medical equipment and supplies'),
('Herbal', 'Herbal and natural remedies');

-- Insert Sample Suppliers
INSERT INTO suppliers (name, contact_person, phone, email, address, is_active) VALUES
('MedSupply Inc.', 'John Doe', '+231-555-0001', 'john@medsupply.com', 'Monrovia, Liberia', TRUE),
('Pharma Distributors', 'Jane Smith', '+231-555-0002', 'jane@pharmadist.com', 'Monrovia, Liberia', TRUE),
('Global Health Supplies', 'Mike Johnson', '+231-555-0003', 'mike@globalhealth.com', 'Paynesville, Liberia', TRUE);

-- Insert System Settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('currency_rate_usd_to_lrd', '150', 'Exchange rate from USD to LRD'),
('low_stock_threshold', '10', 'Minimum quantity for low stock alert'),
('expiry_alert_days', '30', 'Days before expiry to show alert'),
('session_timeout_minutes', '30', 'Session timeout in minutes'),
('max_login_attempts', '5', 'Maximum failed login attempts before lockout'),
('lockout_duration_minutes', '15', 'Account lockout duration in minutes');

-- Note: Actual stock data from your 157 Boystown Pharmacy items
-- should be imported via the CSV import feature in the application
