const db = require('../config/db');

// Check if user has required role
const requireRole = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        message: 'Insufficient permissions'
      });
    }

    next();
  };
};

// Check if user has permission for specific module
const requirePermission = (module, permissionType = 'read') => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Authentication required'
        });
      }

      // Admin has all permissions
      if (req.user.role === 'admin') {
        return next();
      }

      // Check worker permissions
      const [permissions] = await db.query(
        `SELECT * FROM user_permissions 
         WHERE user_id = ? 
         AND module = ? 
         AND (expires_at IS NULL OR expires_at > NOW())`,
        [req.user.userId, module]
      );

      if (permissions.length === 0) {
        return res.status(403).json({
          success: false,
          message: `No access to ${module} module`
        });
      }

      const permission = permissions[0];
      
      // Check specific permission type
      if (permissionType === 'read' && !permission.can_read) {
        return res.status(403).json({
          success: false,
          message: `No read access to ${module} module`
        });
      }

      if (permissionType === 'write' && !permission.can_write) {
        return res.status(403).json({
          success: false,
          message: `No write access to ${module} module`
        });
      }

      next();
    } catch (error) {
      console.error('Permission check error:', error);
      return res.status(500).json({
        success: false,
        message: 'Permission verification failed'
      });
    }
  };
};

module.exports = {
  requireRole,
  requirePermission
};
