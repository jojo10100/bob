const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body } = require('express-validator');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');
const { validate } = require('../middleware/validator');
const { sendPasswordResetEmail, sendWelcomeEmail } = require('../utils/emailService');

// Login endpoint
router.post('/login', [
  body('email').isEmail().withMessage('Valid email is required'),
  body('password').notEmpty().withMessage('Password is required'),
  validate
], async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const [users] = await db.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }

    const user = users[0];

    // Check if account is locked
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      const remainingTime = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
      return res.status(403).json({
        success: false,
        message: `Account locked. Try again in ${remainingTime} minutes`
      });
    }

    // Check if user is active
    if (!user.is_active) {
      return res.status(403).json({
        success: false,
        message: 'Account is deactivated. Contact administrator'
      });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      // Increment login attempts
      const newAttempts = user.login_attempts + 1;
      const maxAttempts = parseInt(process.env.MAX_LOGIN_ATTEMPTS) || 5;

      if (newAttempts >= maxAttempts) {
        const lockoutDuration = parseInt(process.env.LOCKOUT_DURATION) || 900000; // 15 minutes
        const lockUntil = new Date(Date.now() + lockoutDuration);

        await db.query(
          'UPDATE users SET login_attempts = ?, locked_until = ? WHERE id = ?',
          [newAttempts, lockUntil, user.id]
        );

        return res.status(403).json({
          success: false,
          message: 'Account locked due to multiple failed login attempts'
        });
      }

      await db.query(
        'UPDATE users SET login_attempts = ? WHERE id = ?',
        [newAttempts, user.id]
      );

      return res.status(401).json({
        success: false,
        message: 'Invalid email or password',
        attemptsRemaining: maxAttempts - newAttempts
      });
    }

    // Reset login attempts on successful login
    await db.query(
      'UPDATE users SET login_attempts = 0, locked_until = NULL WHERE id = ?',
      [user.id]
    );

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '30m' }
    );

    // Log successful login
    await db.query(
      'INSERT INTO audit_log (user_id, action, table_name, ip_address) VALUES (?, ?, ?, ?)',
      [user.id, 'LOGIN', 'users', req.ip]
    );

    res.json({
      success: true,
      message: 'Login successful',
      data: {
        token,
        user: {
          id: user.id,
          email: user.email,
          fullName: user.full_name,
          role: user.role
        }
      }
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Login failed'
    });
  }
});

// Register new worker (Admin only)
router.post('/register', [
  authenticateToken,
  requireRole('admin'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('password')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('Password must contain uppercase, lowercase, number and special character'),
  body('fullName').notEmpty().withMessage('Full name is required'),
  body('phone').optional(),
  validate
], async (req, res) => {
  try {
    const { email, password, fullName, phone } = req.body;

    // Check if email already exists
    const [existing] = await db.query(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    if (existing.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Email already registered'
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert new user
    const [result] = await db.query(
      'INSERT INTO users (email, password, full_name, phone, role) VALUES (?, ?, ?, ?, ?)',
      [email, hashedPassword, fullName, phone || null, 'worker']
    );

    // Log registration
    await db.query(
      'INSERT INTO audit_log (user_id, action, table_name, record_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'CREATE_USER', 'users', result.insertId]
    );

    // Send welcome email (async, don't wait)
    sendWelcomeEmail(email, fullName, password).catch(err => {
      console.error('Failed to send welcome email:', err);
    });

    res.status(201).json({
      success: true,
      message: 'Worker account created successfully',
      data: {
        userId: result.insertId,
        email,
        fullName
      }
    });

  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Registration failed'
    });
  }
});

// Validate token
router.get('/validate', authenticateToken, async (req, res) => {
  try {
    // Get user permissions if worker
    let permissions = [];
    
    if (req.user.role === 'worker') {
      const [perms] = await db.query(
        `SELECT module, can_read, can_write, expires_at 
         FROM user_permissions 
         WHERE user_id = ? 
         AND (expires_at IS NULL OR expires_at > NOW())`,
        [req.user.userId]
      );
      permissions = perms;
    }

    res.json({
      success: true,
      data: {
        user: req.user,
        permissions
      }
    });

  } catch (error) {
    console.error('Validation error:', error);
    res.status(500).json({
      success: false,
      message: 'Validation failed'
    });
  }
});

// Forgot password
router.post('/forgot-password', [
  body('email').isEmail().withMessage('Valid email is required'),
  validate
], async (req, res) => {
  try {
    const { email } = req.body;

    const [users] = await db.query(
      'SELECT id FROM users WHERE email = ?',
      [email]
    );

    // Don't reveal if email exists
    if (users.length === 0) {
      return res.json({
        success: true,
        message: 'If the email exists, a reset link will be sent'
      });
    }

    // Generate reset token
    const resetToken = jwt.sign(
      { userId: users[0].id },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    const expiresAt = new Date(Date.now() + 3600000); // 1 hour

    await db.query(
      'INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)',
      [users[0].id, resetToken, expiresAt]
    );

    // Send password reset email
    const emailResult = await sendPasswordResetEmail(
      email,
      resetToken,
      users[0].full_name
    );

    if (!emailResult.success) {
      console.warn('Failed to send reset email:', emailResult.message);
      // Still return success to user (don't reveal if email exists)
      // In development, return token for testing
      return res.json({
        success: true,
        message: 'If the email exists, a password reset link has been sent',
        ...(process.env.NODE_ENV === 'development' && { resetToken })
      });
    }
    
    res.json({
      success: true,
      message: 'Password reset link sent to your email'
    });

  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({
      success: false,
      message: 'Request failed'
    });
  }
});

// Reset password
router.post('/reset-password', [
  body('token').notEmpty().withMessage('Reset token is required'),
  body('newPassword')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('Password must contain uppercase, lowercase, number and special character'),
  validate
], async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    // Verify token
    const [tokens] = await db.query(
      'SELECT * FROM password_reset_tokens WHERE token = ? AND used = FALSE AND expires_at > NOW()',
      [token]
    );

    if (tokens.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired reset token'
      });
    }

    const resetToken = tokens[0];

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    await db.query(
      'UPDATE users SET password = ?, login_attempts = 0, locked_until = NULL WHERE id = ?',
      [hashedPassword, resetToken.user_id]
    );

    // Mark token as used
    await db.query(
      'UPDATE password_reset_tokens SET used = TRUE WHERE id = ?',
      [resetToken.id]
    );

    res.json({
      success: true,
      message: 'Password reset successful'
    });

  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({
      success: false,
      message: 'Password reset failed'
    });
  }
});

module.exports = router;
