const express = require('express');
const router = express.Router();
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requirePermission } = require('../middleware/role');

// Get dashboard statistics
router.get('/stats', authenticateToken, async (req, res) => {
  try {
    // Total stock value
    const [stockValue] = await db.query(`
      SELECT 
        SUM(quantity * buying_price_usd) as total_value_usd,
        SUM(quantity * selling_price_lrd) as total_value_lrd,
        COUNT(*) as total_products
      FROM stock
      WHERE is_discontinued = FALSE
    `);

    // Today's sales
    const [todaySales] = await db.query(`
      SELECT 
        COUNT(*) as total_sales,
        COALESCE(SUM(total_lrd), 0) as revenue_lrd,
        COALESCE(SUM(total_usd), 0) as cost_usd,
        COALESCE(SUM(profit), 0) as profit
      FROM sales
      WHERE DATE(sale_date) = CURDATE()
    `);

    // This week's sales
    const [weekSales] = await db.query(`
      SELECT 
        COALESCE(SUM(total_lrd), 0) as revenue_lrd,
        COALESCE(SUM(profit), 0) as profit
      FROM sales
      WHERE YEARWEEK(sale_date) = YEARWEEK(CURDATE())
    `);

    // This month's sales
    const [monthSales] = await db.query(`
      SELECT 
        COALESCE(SUM(total_lrd), 0) as revenue_lrd,
        COALESCE(SUM(profit), 0) as profit
      FROM sales
      WHERE YEAR(sale_date) = YEAR(CURDATE())
      AND MONTH(sale_date) = MONTH(CURDATE())
    `);

    // Low stock count
    const [lowStock] = await db.query(`
      SELECT COUNT(*) as count
      FROM stock
      WHERE quantity <= min_stock_level
      AND is_discontinued = FALSE
    `);

    // Expiring soon count (next 30 days)
    const [expiringSoon] = await db.query(`
      SELECT COUNT(*) as count
      FROM stock
      WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
      AND is_discontinued = FALSE
    `);

    // Expired products
    const [expired] = await db.query(`
      SELECT COUNT(*) as count
      FROM stock
      WHERE expiry_date < CURDATE()
      AND is_discontinued = FALSE
    `);

    // Out of stock
    const [outOfStock] = await db.query(`
      SELECT COUNT(*) as count
      FROM stock
      WHERE quantity = 0
      AND is_discontinued = FALSE
    `);

    res.json({
      success: true,
      data: {
        inventory: {
          totalProducts: stockValue[0].total_products,
          totalValueUSD: parseFloat(stockValue[0].total_value_usd || 0).toFixed(2),
          totalValueLRD: parseFloat(stockValue[0].total_value_lrd || 0).toFixed(2),
          lowStockCount: lowStock[0].count,
          expiringSoonCount: expiringSoon[0].count,
          expiredCount: expired[0].count,
          outOfStockCount: outOfStock[0].count
        },
        sales: {
          today: {
            count: todaySales[0].total_sales,
            revenue: parseFloat(todaySales[0].revenue_lrd).toFixed(2),
            profit: parseFloat(todaySales[0].profit).toFixed(2)
          },
          week: {
            revenue: parseFloat(weekSales[0].revenue_lrd).toFixed(2),
            profit: parseFloat(weekSales[0].profit).toFixed(2)
          },
          month: {
            revenue: parseFloat(monthSales[0].revenue_lrd).toFixed(2),
            profit: parseFloat(monthSales[0].profit).toFixed(2)
          }
        }
      }
    });

  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve dashboard statistics'
    });
  }
});

// Get alerts
router.get('/alerts', authenticateToken, async (req, res) => {
  try {
    // Low stock alerts
    const [lowStock] = await db.query(`
      SELECT id, sn, product_description, quantity, min_stock_level
      FROM stock
      WHERE quantity <= min_stock_level
      AND is_discontinued = FALSE
      ORDER BY quantity ASC
      LIMIT 10
    `);

    // Expiring soon alerts
    const [expiringSoon] = await db.query(`
      SELECT id, sn, product_description, expiry_date, quantity
      FROM stock
      WHERE expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
      AND is_discontinued = FALSE
      ORDER BY expiry_date ASC
      LIMIT 10
    `);

    // Expired products
    const [expired] = await db.query(`
      SELECT id, sn, product_description, expiry_date, quantity
      FROM stock
      WHERE expiry_date < CURDATE()
      AND is_discontinued = FALSE
      ORDER BY expiry_date DESC
      LIMIT 10
    `);

    // Out of stock
    const [outOfStock] = await db.query(`
      SELECT id, sn, product_description, min_stock_level
      FROM stock
      WHERE quantity = 0
      AND is_discontinued = FALSE
      LIMIT 10
    `);

    res.json({
      success: true,
      data: {
        lowStock,
        expiringSoon,
        expired,
        outOfStock
      }
    });

  } catch (error) {
    console.error('Dashboard alerts error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve alerts'
    });
  }
});

// Get sales trend (last 7 days)
router.get('/sales-trend', authenticateToken, async (req, res) => {
  try {
    const { days = 7 } = req.query;

    const [trend] = await db.query(`
      SELECT 
        DATE(sale_date) as date,
        COUNT(*) as sales_count,
        COALESCE(SUM(total_lrd), 0) as revenue,
        COALESCE(SUM(profit), 0) as profit
      FROM sales
      WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
      GROUP BY DATE(sale_date)
      ORDER BY date ASC
    `, [parseInt(days)]);

    res.json({
      success: true,
      data: trend
    });

  } catch (error) {
    console.error('Sales trend error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve sales trend'
    });
  }
});

// Get top selling products
router.get('/top-products', authenticateToken, async (req, res) => {
  try {
    const { limit = 5 } = req.query;

    const [products] = await db.query(`
      SELECT 
        si.product_sn,
        si.product_description,
        SUM(si.quantity) as total_sold,
        SUM(si.subtotal_lrd) as total_revenue,
        SUM(si.profit) as total_profit
      FROM sale_items si
      JOIN sales s ON si.sale_id = s.id
      WHERE s.sale_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
      GROUP BY si.product_sn, si.product_description
      ORDER BY total_sold DESC
      LIMIT ?
    `, [parseInt(limit)]);

    res.json({
      success: true,
      data: products
    });

  } catch (error) {
    console.error('Top products error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve top products'
    });
  }
});

// Get stock distribution by category
router.get('/category-distribution', authenticateToken, async (req, res) => {
  try {
    const [distribution] = await db.query(`
      SELECT 
        c.name as category,
        COUNT(s.id) as product_count,
        SUM(s.quantity) as total_quantity,
        SUM(s.quantity * s.buying_price_usd) as total_value_usd
      FROM stock s
      LEFT JOIN categories c ON s.category_id = c.id
      WHERE s.is_discontinued = FALSE
      GROUP BY c.id, c.name
      ORDER BY product_count DESC
    `);

    res.json({
      success: true,
      data: distribution
    });

  } catch (error) {
    console.error('Category distribution error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve category distribution'
    });
  }
});

module.exports = router;
