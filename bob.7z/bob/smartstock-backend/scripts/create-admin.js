require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

async function createAdmin() {
  try {
    console.log('🔌 Connecting to database...');
    
    const connection = await mysql.createConnection({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME || 'smartstock_db'
    });

    console.log('✅ Connected to database');
    console.log('🔐 Hashing password...');
    
    const email = process.env.ADMIN_EMAIL || 'admin@boystown.com';
    const password = process.env.ADMIN_PASSWORD || 'Admin@123';
    const hashedPassword = await bcrypt.hash(password, 10);

    console.log('💾 Creating admin user...');
    
    // Insert or update admin user
    await connection.query(
      `INSERT INTO users (email, password, full_name, role, is_active) 
       VALUES (?, ?, ?, ?, ?) 
       ON DUPLICATE KEY UPDATE password = ?, full_name = ?, is_active = ?`,
      [email, hashedPassword, 'System Administrator', 'admin', true, hashedPassword, 'System Administrator', true]
    );

    console.log('\n✅ Admin user created successfully!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log(`📧 Email: ${email}`);
    console.log(`🔑 Password: ${password}`);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('\n⚠️  IMPORTANT: Change the password after first login!\n');
    
    await connection.end();
    process.exit(0);
    
  } catch (error) {
    console.error('❌ Error creating admin user:', error.message);
    process.exit(1);
  }
}

createAdmin();
