// Dashboard JavaScript

let salesTrendChart = null;
let categoryChart = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Check authentication
  if (!auth.isAuthenticated()) {
    window.location.href = '/login.html';
    return;
  }

  // Validate token
  const isValid = await auth.validateToken();
  if (!isValid) {
    return;
  }

  // Initialize dashboard
  initializeDashboard();
  loadDashboardData();

  // Event listeners
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      auth.logout();
    }
  });

  document.getElementById('refreshBtn').addEventListener('click', () => {
    loadDashboardData();
  });

  const quickSaleBtn = document.getElementById('quickSaleBtn');
  const quickSaleModal = document.getElementById('quickSaleModal');
  const closeQuickSale = document.getElementById('closeQuickSale');

  quickSaleBtn.addEventListener('click', () => {
    ui.showModal('quickSaleModal');
  });

  closeQuickSale.addEventListener('click', () => {
    ui.hideModal('quickSaleModal');
  });

  quickSaleModal.addEventListener('click', (e) => {
    if (e.target === quickSaleModal) {
      ui.hideModal('quickSaleModal');
    }
  });
});

function initializeDashboard() {
  const user = auth.getUser();
  
  if (!user) {
    auth.logout();
    return;
  }

  // Update user info
  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userRole').textContent = user.role;

  // Show/hide admin elements
  if (user.role === 'admin') {
    document.body.classList.add('is-admin');
  }

  // Update navigation based on permissions
  updateNavigation();
}

function updateNavigation() {
  const navItems = [
    { id: 'navStockManagement', module: 'stock' },
    { id: 'navInventory', module: 'inventory' },
    { id: 'navSales', module: 'sales' },
    { id: 'navReports', module: 'reports' }
  ];

  navItems.forEach(item => {
    const navElement = document.getElementById(item.id);
    if (navElement && !auth.hasPermission(item.module, 'read')) {
      navElement.style.display = 'none';
    }
  });
}

async function loadDashboardData() {
  try {
    // Show loading state
    ui.showAlert('Loading dashboard data...', 'info');

    // Load all data in parallel
    const [stats, alerts, salesTrend, topProducts, categoryDist] = await Promise.all([
      loadStatistics(),
      loadAlerts(),
      loadSalesTrend(),
      loadTopProducts(),
      loadCategoryDistribution()
    ]);

    // Update UI with loaded data
    updateStatistics(stats);
    updateAlerts(alerts);
    updateSalesTrendChart(salesTrend);
    updateTopProductsTable(topProducts);
    updateCategoryChart(categoryDist);

    ui.showAlert('Dashboard updated successfully', 'success');

  } catch (error) {
    console.error('Dashboard load error:', error);
    ui.showAlert('Failed to load dashboard data', 'error');
  }
}

async function loadStatistics() {
  try {
    const response = await api.get('/dashboard/stats');
    return response.data;
  } catch (error) {
    console.error('Load statistics error:', error);
    return null;
  }
}

async function loadAlerts() {
  try {
    const response = await api.get('/dashboard/alerts');
    return response.data;
  } catch (error) {
    console.error('Load alerts error:', error);
    return null;
  }
}

async function loadSalesTrend() {
  try {
    const response = await api.get('/dashboard/sales-trend?days=7');
    return response.data;
  } catch (error) {
    console.error('Load sales trend error:', error);
    return [];
  }
}

async function loadTopProducts() {
  try {
    const response = await api.get('/dashboard/top-products?limit=5');
    return response.data;
  } catch (error) {
    console.error('Load top products error:', error);
    return [];
  }
}

async function loadCategoryDistribution() {
  try {
    const response = await api.get('/dashboard/category-distribution');
    return response.data;
  } catch (error) {
    console.error('Load category distribution error:', error);
    return [];
  }
}

function updateStatistics(stats) {
  if (!stats) return;

  // Update stat cards
  document.getElementById('totalProducts').textContent = stats.inventory.totalProducts || 0;
  document.getElementById('stockValueUSD').textContent = ui.formatUSD(stats.inventory.totalValueUSD || 0);
  document.getElementById('todayRevenue').textContent = ui.formatLRD(stats.sales.today.revenue || 0);
  document.getElementById('todayProfit').textContent = ui.formatLRD(stats.sales.today.profit || 0);
}

function updateAlerts(alerts) {
  if (!alerts) return;

  const alertsSection = document.getElementById('alertsSection');
  let hasAlerts = false;

  // Low stock alert
  if (alerts.lowStock && alerts.lowStock.length > 0) {
    document.getElementById('lowStockCount').textContent = alerts.lowStock.length;
    document.getElementById('lowStockAlert').style.display = 'flex';
    updateLowStockTable(alerts.lowStock);
    hasAlerts = true;
  }

  // Expiring soon alert
  if (alerts.expiringSoon && alerts.expiringSoon.length > 0) {
    document.getElementById('expiringCount').textContent = alerts.expiringSoon.length;
    document.getElementById('expiringAlert').style.display = 'flex';
    hasAlerts = true;
  }

  // Expired alert
  if (alerts.expired && alerts.expired.length > 0) {
    document.getElementById('expiredCount').textContent = alerts.expired.length;
    document.getElementById('expiredAlert').style.display = 'flex';
    hasAlerts = true;
  }

  // Out of stock alert
  if (alerts.outOfStock && alerts.outOfStock.length > 0) {
    document.getElementById('outOfStockCount').textContent = alerts.outOfStock.length;
    document.getElementById('outOfStockAlert').style.display = 'flex';
    hasAlerts = true;
  }

  // Show/hide alerts section
  if (hasAlerts) {
    alertsSection.style.display = 'block';
  }
}

function updateSalesTrendChart(data) {
  const ctx = document.getElementById('salesTrendChart');
  
  if (!ctx) return;

  // Destroy existing chart
  if (salesTrendChart) {
    salesTrendChart.destroy();
  }

  // Prepare data
  const labels = data.map(item => ui.formatDate(item.date));
  const revenueData = data.map(item => parseFloat(item.revenue) || 0);
  const profitData = data.map(item => parseFloat(item.profit) || 0);

  // Create new chart
  salesTrendChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Revenue (LRD)',
          data: revenueData,
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: 'rgba(75, 192, 192, 0.2)',
          tension: 0.4,
          fill: true
        },
        {
          label: 'Profit (LRD)',
          data: profitData,
          borderColor: 'rgb(40, 167, 69)',
          backgroundColor: 'rgba(40, 167, 69, 0.2)',
          tension: 0.4,
          fill: true
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: true,
          position: 'top'
        },
        tooltip: {
          mode: 'index',
          intersect: false,
          callbacks: {
            label: function(context) {
              let label = context.dataset.label || '';
              if (label) {
                label += ': ';
              }
              label += ui.formatLRD(context.parsed.y);
              return label;
            }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            callback: function(value) {
              return 'L$' + value.toLocaleString();
            }
          }
        }
      }
    }
  });
}

function updateCategoryChart(data) {
  const ctx = document.getElementById('categoryChart');
  
  if (!ctx) return;

  // Destroy existing chart
  if (categoryChart) {
    categoryChart.destroy();
  }

  // Prepare data
  const labels = data.map(item => item.category || 'Uncategorized');
  const productCounts = data.map(item => item.product_count || 0);
  
  // Generate colors
  const colors = [
    'rgba(255, 99, 132, 0.8)',
    'rgba(54, 162, 235, 0.8)',
    'rgba(255, 206, 86, 0.8)',
    'rgba(75, 192, 192, 0.8)',
    'rgba(153, 102, 255, 0.8)',
    'rgba(255, 159, 64, 0.8)',
    'rgba(199, 199, 199, 0.8)',
    'rgba(83, 102, 255, 0.8)'
  ];

  // Create new chart
  categoryChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: labels,
      datasets: [{
        data: productCounts,
        backgroundColor: colors,
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: true,
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const label = context.label || '';
              const value = context.parsed || 0;
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const percentage = ((value / total) * 100).toFixed(1);
              return `${label}: ${value} (${percentage}%)`;
            }
          }
        }
      }
    }
  });
}

function updateTopProductsTable(products) {
  const tbody = document.getElementById('topProductsTable');
  
  if (!tbody) return;

  if (!products || products.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No data available</td></tr>';
    return;
  }

  tbody.innerHTML = products.map(product => `
    <tr>
      <td>
        <strong>${escapeHtml(product.product_description)}</strong><br>
        <small class="text-muted">SN: ${escapeHtml(product.product_sn)}</small>
      </td>
      <td>${product.total_sold || 0}</td>
      <td>${ui.formatLRD(product.total_revenue || 0)}</td>
    </tr>
  `).join('');
}

function updateLowStockTable(items) {
  const tbody = document.getElementById('lowStockTable');
  
  if (!tbody) return;

  if (!items || items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" class="text-center text-muted">No low stock items</td></tr>';
    return;
  }

  tbody.innerHTML = items.map(item => `
    <tr>
      <td>
        <strong>${escapeHtml(item.product_description)}</strong><br>
        <small class="text-muted">SN: ${escapeHtml(item.sn)}</small>
      </td>
      <td>
        <span class="text-warning">
          <strong>${item.quantity}</strong> / ${item.min_stock_level}
        </span>
      </td>
      <td>
        <a href="data-management.html?id=${item.id}" class="btn btn-sm btn-info">
          <i class="fas fa-edit"></i> Update
        </a>
      </td>
    </tr>
  `).join('');
}

// Helper function to escape HTML
function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}
