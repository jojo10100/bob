// Stock Management JavaScript

let stockData = [];
let filteredData = [];
let currentPage = 1;
let itemsPerPage = 20;
let sortColumn = 'product_description';
let sortOrder = 'ASC';
let categories = [];
let suppliers = [];

document.addEventListener('DOMContentLoaded', async () => {
  // Check authentication and permissions
  if (!auth.isAuthenticated()) {
    window.location.href = '/login.html';
    return;
  }

  if (!auth.hasPermission('stock', 'read')) {
    ui.showAlert('You do not have permission to access this page', 'error');
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 2000);
    return;
  }

  // Initialize page
  initializePage();
  await loadDropdownData();
  await loadStockData();

  // Event listeners
  setupEventListeners();
});

function initializePage() {
  const user = auth.getUser();
  
  if (!user) {
    auth.logout();
    return;
  }

  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userRole').textContent = user.role;

  if (user.role === 'admin') {
    document.body.classList.add('is-admin');
  }

  // Hide write actions if no write permission
  if (!auth.hasPermission('stock', 'write')) {
    document.getElementById('addStockBtn').style.display = 'none';
    document.getElementById('importBtn').style.display = 'none';
  }
}

function setupEventListeners() {
  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      auth.logout();
    }
  });

  // Add Stock button
  document.getElementById('addStockBtn').addEventListener('click', () => {
    openStockModal();
  });

  // Import button
  document.getElementById('importBtn').addEventListener('click', () => {
    ui.showModal('importModal');
  });

  // Export button
  document.getElementById('exportBtn').addEventListener('click', () => {
    exportToCSV();
  });

  // Search
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', ui.debounce(() => {
    filterData();
  }, 300));

  // Filters
  document.getElementById('categoryFilter').addEventListener('change', filterData);
  document.getElementById('supplierFilter').addEventListener('change', filterData);
  document.getElementById('statusFilter').addEventListener('change', filterData);

  // Pagination
  document.getElementById('prevPage').addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      renderTable();
    }
  });

  document.getElementById('nextPage').addEventListener('click', () => {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    if (currentPage < totalPages) {
      currentPage++;
      renderTable();
    }
  });

  // Table sorting
  document.querySelectorAll('.table th[data-sort]').forEach(th => {
    th.addEventListener('click', () => {
      const column = th.dataset.sort;
      if (sortColumn === column) {
        sortOrder = sortOrder === 'ASC' ? 'DESC' : 'ASC';
      } else {
        sortColumn = column;
        sortOrder = 'ASC';
      }
      updateSortIndicators();
      sortData();
      renderTable();
    });
  });

  // Stock form
  document.getElementById('stockForm').addEventListener('submit', handleStockSubmit);
  document.getElementById('cancelBtn').addEventListener('click', closeStockModal);
  document.getElementById('closeStockModal').addEventListener('click', closeStockModal);

  // Import form
  document.getElementById('importForm').addEventListener('submit', handleImportSubmit);
  document.getElementById('cancelImportBtn').addEventListener('click', () => {
    ui.hideModal('importModal');
  });
  document.getElementById('closeImportModal').addEventListener('click', () => {
    ui.hideModal('importModal');
  });

  // Modal outside click
  document.getElementById('stockModal').addEventListener('click', (e) => {
    if (e.target.id === 'stockModal') closeStockModal();
  });
  document.getElementById('importModal').addEventListener('click', (e) => {
    if (e.target.id === 'importModal') ui.hideModal('importModal');
  });
}

async function loadDropdownData() {
  try {
    // Load categories
    const categoriesResponse = await api.get('/categories');
    categories = categoriesResponse.data;
    
    const categorySelects = [
      document.getElementById('categoryFilter'),
      document.getElementById('categoryId')
    ];
    
    categorySelects.forEach(select => {
      if (select) {
        categories.forEach(cat => {
          const option = document.createElement('option');
          option.value = cat.id;
          option.textContent = cat.name;
          select.appendChild(option);
        });
      }
    });

    // Load suppliers
    const suppliersResponse = await api.get('/suppliers?active_only=true');
    suppliers = suppliersResponse.data;
    
    const supplierSelects = [
      document.getElementById('supplierFilter'),
      document.getElementById('supplierId')
    ];
    
    supplierSelects.forEach(select => {
      if (select) {
        suppliers.forEach(sup => {
          const option = document.createElement('option');
          option.value = sup.id;
          option.textContent = sup.name;
          select.appendChild(option);
        });
      }
    });

  } catch (error) {
    console.error('Load dropdown data error:', error);
  }
}

async function loadStockData() {
  try {
    ui.showAlert('Loading stock data...', 'info');
    
    const response = await api.get('/stock?limit=1000');
    stockData = response.data.stock || [];
    filteredData = [...stockData];
    
    sortData();
    renderTable();
    
    ui.showAlert('Stock data loaded successfully', 'success');
  } catch (error) {
    console.error('Load stock error:', error);
    ui.showAlert('Failed to load stock data', 'error');
  }
}

function filterData() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase();
  const categoryFilter = document.getElementById('categoryFilter').value;
  const supplierFilter = document.getElementById('supplierFilter').value;
  const statusFilter = document.getElementById('statusFilter').value;

  filteredData = stockData.filter(item => {
    // Search filter
    const matchesSearch = !searchTerm || 
      item.sn.toLowerCase().includes(searchTerm) ||
      item.product_description.toLowerCase().includes(searchTerm) ||
      (item.batch_number && item.batch_number.toLowerCase().includes(searchTerm));

    // Category filter
    const matchesCategory = !categoryFilter || item.category_id == categoryFilter;

    // Supplier filter
    const matchesSupplier = !supplierFilter || item.supplier_id == supplierFilter;

    // Status filter
    let matchesStatus = true;
    if (statusFilter === 'low-stock') {
      matchesStatus = item.quantity <= item.min_stock_level;
    } else if (statusFilter === 'expiring') {
      const today = new Date();
      const expiryDate = new Date(item.expiry_date);
      const daysUntilExpiry = Math.floor((expiryDate - today) / (1000 * 60 * 60 * 24));
      matchesStatus = daysUntilExpiry >= 0 && daysUntilExpiry <= 30;
    } else if (statusFilter === 'out-of-stock') {
      matchesStatus = item.quantity === 0;
    }

    return matchesSearch && matchesCategory && matchesSupplier && matchesStatus;
  });

  currentPage = 1;
  renderTable();
}

function sortData() {
  filteredData.sort((a, b) => {
    let aVal = a[sortColumn];
    let bVal = b[sortColumn];

    // Handle null values
    if (aVal === null) aVal = '';
    if (bVal === null) bVal = '';

    // String comparison
    if (typeof aVal === 'string') {
      return sortOrder === 'ASC' 
        ? aVal.localeCompare(bVal)
        : bVal.localeCompare(aVal);
    }

    // Numeric comparison
    return sortOrder === 'ASC' ? aVal - bVal : bVal - aVal;
  });
}

function updateSortIndicators() {
  document.querySelectorAll('.table th[data-sort]').forEach(th => {
    th.classList.remove('sort-asc', 'sort-desc');
    if (th.dataset.sort === sortColumn) {
      th.classList.add(sortOrder === 'ASC' ? 'sort-asc' : 'sort-desc');
    }
  });
}

function renderTable() {
  const tbody = document.getElementById('stockTableBody');
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const pageData = filteredData.slice(startIndex, endIndex);

  if (pageData.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">No stock items found</td></tr>';
  } else {
    tbody.innerHTML = pageData.map(item => createTableRow(item)).join('');
  }

  // Update pagination info
  document.getElementById('currentPage').textContent = currentPage;
  document.getElementById('totalPages').textContent = totalPages || 1;
  document.getElementById('tableInfo').textContent = `Showing ${startIndex + 1}-${Math.min(endIndex, filteredData.length)} of ${filteredData.length} items`;

  // Update pagination buttons
  document.getElementById('prevPage').disabled = currentPage === 1;
  document.getElementById('nextPage').disabled = currentPage === totalPages || totalPages === 0;

  // Add event listeners to action buttons
  attachActionListeners();
}

function createTableRow(item) {
  const stockStatus = getStockStatus(item);
  const expiryStatus = getExpiryStatus(item);
  const canWrite = auth.hasPermission('stock', 'write');

  return `
    <tr data-id="${item.id}">
      <td><strong>${escapeHtml(item.sn)}</strong></td>
      <td>
        ${escapeHtml(item.product_description)}
        ${item.batch_number ? `<br><small class="text-muted">Batch: ${escapeHtml(item.batch_number)}</small>` : ''}
      </td>
      <td>${item.category_name || 'N/A'}</td>
      <td>
        <span class="stock-status ${stockStatus.class}">
          ${stockStatus.icon} ${item.quantity}
        </span>
      </td>
      <td>${ui.formatUSD(item.buying_price_usd)}</td>
      <td>${ui.formatLRD(item.selling_price_lrd)}</td>
      <td>
        <span class="expiry-status ${expiryStatus.class}">
          ${expiryStatus.text}
        </span>
      </td>
      <td>
        <div class="action-buttons">
          ${canWrite ? `
            <button class="btn btn-sm btn-info edit-btn" data-id="${item.id}" title="Edit">
              <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-danger delete-btn" data-id="${item.id}" title="Delete">
              <i class="fas fa-trash"></i>
            </button>
          ` : `
            <button class="btn btn-sm btn-info view-btn" data-id="${item.id}" title="View">
              <i class="fas fa-eye"></i>
            </button>
          `}
        </div>
      </td>
    </tr>
  `;
}

function getStockStatus(item) {
  if (item.quantity === 0) {
    return { class: 'out', icon: '<i class="fas fa-times-circle"></i>' };
  } else if (item.quantity <= item.min_stock_level) {
    return { class: 'low', icon: '<i class="fas fa-exclamation-triangle"></i>' };
  } else {
    return { class: 'good', icon: '<i class="fas fa-check-circle"></i>' };
  }
}

function getExpiryStatus(item) {
  if (!item.expiry_date) {
    return { class: '', text: 'N/A' };
  }

  const today = new Date();
  const expiryDate = new Date(item.expiry_date);
  const daysUntilExpiry = Math.floor((expiryDate - today) / (1000 * 60 * 60 * 24));

  if (daysUntilExpiry < 0) {
    return { class: 'expired', text: 'Expired' };
  } else if (daysUntilExpiry <= 30) {
    return { class: 'expiring-soon', text: ui.formatDate(item.expiry_date) };
  } else {
    return { class: '', text: ui.formatDate(item.expiry_date) };
  }
}

function attachActionListeners() {
  // Edit buttons
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.dataset.id;
      const item = stockData.find(s => s.id == id);
      if (item) openStockModal(item);
    });
  });

  // Delete buttons
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.dataset.id;
      if (await ui.confirm('Are you sure you want to delete this stock item?')) {
        deleteStockItem(id);
      }
    });
  });

  // View buttons
  document.querySelectorAll('.view-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.dataset.id;
      const item = stockData.find(s => s.id == id);
      if (item) openStockModal(item, true);
    });
  });
}

function openStockModal(item = null, viewOnly = false) {
  const modal = document.getElementById('stockModal');
  const form = document.getElementById('stockForm');
  
  form.reset();

  if (item) {
    document.getElementById('modalTitle').textContent = viewOnly ? 'View Stock Item' : 'Edit Stock Item';
    document.getElementById('stockId').value = item.id;
    document.getElementById('sn').value = item.sn;
    document.getElementById('productDescription').value = item.product_description;
    document.getElementById('categoryId').value = item.category_id || '';
    document.getElementById('supplierId').value = item.supplier_id || '';
    document.getElementById('buyingPrice').value = item.buying_price_usd;
    document.getElementById('sellingPrice').value = item.selling_price_lrd;
    document.getElementById('quantity').value = item.quantity;
    document.getElementById('expiryDate').value = item.expiry_date || '';
    document.getElementById('batchNumber').value = item.batch_number || '';
    document.getElementById('minStockLevel').value = item.min_stock_level;

    if (viewOnly) {
      form.querySelectorAll('input, select').forEach(el => el.disabled = true);
      document.getElementById('saveBtn').style.display = 'none';
    }
  } else {
    document.getElementById('modalTitle').textContent = 'Add Stock Item';
    form.querySelectorAll('input, select').forEach(el => el.disabled = false);
    document.getElementById('saveBtn').style.display = 'block';
  }

  ui.showModal('stockModal');
}

function closeStockModal() {
  ui.hideModal('stockModal');
  document.getElementById('stockForm').reset();
}

async function handleStockSubmit(e) {
  e.preventDefault();

  const stockId = document.getElementById('stockId').value;
  const formData = {
    sn: document.getElementById('sn').value,
    product_description: document.getElementById('productDescription').value,
    buying_price_usd: parseFloat(document.getElementById('buyingPrice').value),
    selling_price_lrd: parseFloat(document.getElementById('sellingPrice').value),
    quantity: parseInt(document.getElementById('quantity').value),
    category_id: document.getElementById('categoryId').value || null,
    supplier_id: document.getElementById('supplierId').value || null,
    expiry_date: document.getElementById('expiryDate').value || null,
    batch_number: document.getElementById('batchNumber').value || null,
    min_stock_level: parseInt(document.getElementById('minStockLevel').value) || 10
  };

  try {
    if (stockId) {
      await api.put(`/stock/${stockId}`, formData);
      ui.showAlert('Stock item updated successfully', 'success');
    } else {
      await api.post('/stock', formData);
      ui.showAlert('Stock item added successfully', 'success');
    }

    closeStockModal();
    await loadStockData();
  } catch (error) {
    ui.showAlert(error.message || 'Failed to save stock item', 'error');
  }
}

async function deleteStockItem(id) {
  try {
    await api.delete(`/stock/${id}`);
    ui.showAlert('Stock item deleted successfully', 'success');
    await loadStockData();
  } catch (error) {
    ui.showAlert(error.message || 'Failed to delete stock item', 'error');
  }
}

async function handleImportSubmit(e) {
  e.preventDefault();

  const fileInput = document.getElementById('csvFile');
  const file = fileInput.files[0];

  if (!file) {
    ui.showAlert('Please select a CSV file', 'error');
    return;
  }

  const formData = new FormData();
  formData.append('file', file);

  try {
    document.getElementById('importProgress').style.display = 'block';
    document.getElementById('progressFill').style.width = '50%';
    document.getElementById('progressText').textContent = 'Uploading and processing...';

    const response = await api.upload('/stock/import', formData);

    document.getElementById('progressFill').style.width = '100%';
    document.getElementById('progressText').textContent = 'Import complete!';

    setTimeout(() => {
      ui.hideModal('importModal');
      document.getElementById('importForm').reset();
      document.getElementById('importProgress').style.display = 'none';
      document.getElementById('progressFill').style.width = '0%';
    }, 1500);

    ui.showAlert(response.message, 'success');
    await loadStockData();
  } catch (error) {
    document.getElementById('importProgress').style.display = 'none';
    ui.showAlert(error.message || 'Import failed', 'error');
  }
}

function exportToCSV() {
  const headers = ['SN', 'Product Description', 'Category', 'Supplier', 'Buying Price USD', 'Selling Price LRD', 'Quantity', 'Expiry Date', 'Batch Number', 'Min Stock Level'];
  
  const csvData = filteredData.map(item => [
    item.sn,
    item.product_description,
    item.category_name || '',
    item.supplier_name || '',
    item.buying_price_usd,
    item.selling_price_lrd,
    item.quantity,
    item.expiry_date || '',
    item.batch_number || '',
    item.min_stock_level
  ]);

  const csvContent = [
    headers.join(','),
    ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv' });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `stock_export_${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
  window.URL.revokeObjectURL(url);

  ui.showAlert('Stock data exported successfully', 'success');
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text).replace(/[&<>"']/g, m => map[m]);
}
