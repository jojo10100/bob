// SmartStock Pharmacy - Main JavaScript Utilities

const API_BASE_URL = 'http://localhost:3000/api';

// API Utility Functions
const api = {
  // Make authenticated API request
  async request(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    
    const headers = {
      'Content-Type': 'application/json',
      ...options.headers
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Request failed');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  },

  // GET request
  async get(endpoint) {
    return this.request(endpoint, { method: 'GET' });
  },

  // POST request
  async post(endpoint, body) {
    return this.request(endpoint, {
      method: 'POST',
      body: JSON.stringify(body)
    });
  },

  // PUT request
  async put(endpoint, body) {
    return this.request(endpoint, {
      method: 'PUT',
      body: JSON.stringify(body)
    });
  },

  // DELETE request
  async delete(endpoint) {
    return this.request(endpoint, { method: 'DELETE' });
  },

  // Upload file
  async upload(endpoint, formData) {
    const token = localStorage.getItem('token');
    
    const headers = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers,
      body: formData
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Upload failed');
    }

    return data;
  }
};

// Authentication Functions
const auth = {
  // Login
  async login(email, password) {
    try {
      const response = await api.post('/auth/login', { email, password });
      
      if (response.success) {
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('user', JSON.stringify(response.data.user));
        return response.data;
      }
    } catch (error) {
      throw error;
    }
  },

  // Logout
  logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('permissions');
    window.location.href = '/login.html';
  },

  // Get current user
  getUser() {
    const userJson = localStorage.getItem('user');
    return userJson ? JSON.parse(userJson) : null;
  },

  // Check if user is authenticated
  isAuthenticated() {
    return !!localStorage.getItem('token');
  },

  // Check if user is admin
  isAdmin() {
    const user = this.getUser();
    return user && user.role === 'admin';
  },

  // Validate token
  async validateToken() {
    try {
      const response = await api.get('/auth/validate');
      
      if (response.success) {
        // Update permissions if worker
        if (response.data.permissions) {
          localStorage.setItem('permissions', JSON.stringify(response.data.permissions));
        }
        return true;
      }
      return false;
    } catch (error) {
      this.logout();
      return false;
    }
  },

  // Check permission
  hasPermission(module, type = 'read') {
    const user = this.getUser();
    
    // Admin has all permissions
    if (user && user.role === 'admin') {
      return true;
    }

    // Check worker permissions
    const permissionsJson = localStorage.getItem('permissions');
    if (!permissionsJson) return false;

    const permissions = JSON.parse(permissionsJson);
    const modulePermission = permissions.find(p => p.module === module);

    if (!modulePermission) return false;

    // Check if permission has expired
    if (modulePermission.expires_at) {
      const expiryDate = new Date(modulePermission.expires_at);
      if (expiryDate < new Date()) return false;
    }

    return type === 'read' ? modulePermission.can_read : modulePermission.can_write;
  }
};

// UI Utility Functions
const ui = {
  // Show alert message
  showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    alertDiv.style.position = 'fixed';
    alertDiv.style.top = '20px';
    alertDiv.style.right = '20px';
    alertDiv.style.zIndex = '10000';
    alertDiv.style.minWidth = '300px';
    alertDiv.style.animation = 'slideInRight 0.3s ease';

    document.body.appendChild(alertDiv);

    setTimeout(() => {
      alertDiv.style.animation = 'slideOutRight 0.3s ease';
      setTimeout(() => {
        document.body.removeChild(alertDiv);
      }, 300);
    }, 3000);
  },

  // Show loading spinner
  showLoading(container) {
    const spinner = document.createElement('div');
    spinner.className = 'spinner';
    spinner.id = 'loading-spinner';
    container.innerHTML = '';
    container.appendChild(spinner);
  },

  // Hide loading spinner
  hideLoading() {
    const spinner = document.getElementById('loading-spinner');
    if (spinner) {
      spinner.remove();
    }
  },

  // Format currency (LRD)
  formatLRD(amount) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'LRD',
      minimumFractionDigits: 2
    }).format(amount);
  },

  // Format currency (USD)
  formatUSD(amount) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(amount);
  },

  // Format date
  formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  },

  // Format datetime
  formatDateTime(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  },

  // Confirm dialog
  async confirm(message) {
    return window.confirm(message);
  },

  // Show modal
  showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('show');
    }
  },

  // Hide modal
  hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('show');
    }
  },

  // Validate email
  isValidEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  },

  // Validate password strength
  isValidPassword(password) {
    // At least 8 characters, 1 uppercase, 1 lowercase, 1 number, 1 special char
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
  },

  // Debounce function
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
};

// Dark Mode Functions
const darkMode = {
  // Initialize dark mode
  init() {
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) {
      this.enable();
    }
  },

  // Enable dark mode
  enable() {
    document.body.classList.add('dark-mode');
    localStorage.setItem('darkMode', 'true');
  },

  // Disable dark mode
  disable() {
    document.body.classList.remove('dark-mode');
    localStorage.setItem('darkMode', 'false');
  },

  // Toggle dark mode
  toggle() {
    if (document.body.classList.contains('dark-mode')) {
      this.disable();
    } else {
      this.enable();
    }
  }
};

// Internationalization (i18n)
const i18n = {
  currentLang: 'en',
  
  translations: {
    en: {
      appName: 'SmartStock Pharmacy',
      login: 'Login',
      logout: 'Logout',
      dashboard: 'Dashboard',
      stockManagement: 'Stock Management',
      sales: 'Sales',
      reports: 'Reports',
      settings: 'Settings'
    },
    fr: {
      appName: 'SmartStock Pharmacie',
      login: 'Connexion',
      logout: 'Déconnexion',
      dashboard: 'Tableau de bord',
      stockManagement: 'Gestion des stocks',
      sales: 'Ventes',
      reports: 'Rapports',
      settings: 'Paramètres'
    },
    es: {
      appName: 'SmartStock Farmacia',
      login: 'Iniciar sesión',
      logout: 'Cerrar sesión',
      dashboard: 'Panel',
      stockManagement: 'Gestión de stock',
      sales: 'Ventas',
      reports: 'Informes',
      settings: 'Configuración'
    },
    pt: {
      appName: 'SmartStock Farmácia',
      login: 'Entrar',
      logout: 'Sair',
      dashboard: 'Painel',
      stockManagement: 'Gestão de estoque',
      sales: 'Vendas',
      reports: 'Relatórios',
      settings: 'Configurações'
    }
  },

  // Initialize language
  init() {
    this.currentLang = localStorage.getItem('language') || 'en';
  },

  // Set language
  setLanguage(lang) {
    if (this.translations[lang]) {
      this.currentLang = lang;
      localStorage.setItem('language', lang);
      // Reload page to apply translations
      window.location.reload();
    }
  },

  // Get translation
  t(key) {
    return this.translations[this.currentLang][key] || key;
  }
};

// Export for use in other scripts
window.api = api;
window.auth = auth;
window.ui = ui;
window.darkMode = darkMode;
window.i18n = i18n;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  darkMode.init();
  i18n.init();
});
