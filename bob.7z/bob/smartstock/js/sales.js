// Sales Management JavaScript

let salesData = [];
let saleItems = [];
let currentPage = 1;
let itemsPerPage = 20;
let selectedCustomer = null;
let currentSale = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Check authentication and permissions
  if (!auth.isAuthenticated()) {
    window.location.href = '/login.html';
    return;
  }

  if (!auth.hasPermission('sales', 'read')) {
    ui.showAlert('You do not have permission to access this page', 'error');
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 2000);
    return;
  }

  // Initialize page
  initializePage();
  await loadSalesData();
  setDefaultDates();

  // Event listeners
  setupEventListeners();
});

function initializePage() {
  const user = auth.getUser();
  
  if (!user) {
    auth.logout();
    return;
  }

  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userRole').textContent = user.role;

  if (user.role === 'admin') {
    document.body.classList.add('is-admin');
  }

  // Hide write actions if no write permission
  if (!auth.hasPermission('sales', 'write')) {
    document.getElementById('newSaleBtn').style.display = 'none';
  }
}

function setupEventListeners() {
  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      auth.logout();
    }
  });

  // New Sale button
  document.getElementById('newSaleBtn').addEventListener('click', openNewSaleModal);

  // Refresh button
  document.getElementById('refreshBtn').addEventListener('click', loadSalesData);

  // Filter buttons
  document.getElementById('applyFilters').addEventListener('click', applyFilters);
  document.getElementById('clearFilters').addEventListener('click', clearFilters);

  // Pagination
  document.getElementById('prevPage').addEventListener('click', () => {
    if (currentPage > 1) {
      currentPage--;
      renderSalesTable();
    }
  });

  document.getElementById('nextPage').addEventListener('click', () => {
    const totalPages = Math.ceil(salesData.length / itemsPerPage);
    if (currentPage < totalPages) {
      currentPage++;
      renderSalesTable();
    }
  });

  // New Sale Modal
  document.getElementById('closeNewSaleModal').addEventListener('click', closeNewSaleModal);
  document.getElementById('cancelSale').addEventListener('click', closeNewSaleModal);
  document.getElementById('newSaleForm').addEventListener('submit', handleSaleSubmit);

  // Customer search
  const customerSearch = document.getElementById('customerSearch');
  customerSearch.addEventListener('input', ui.debounce(() => {
    searchCustomers(customerSearch.value);
  }, 300));

  document.getElementById('walkInCustomer').addEventListener('click', () => {
    selectedCustomer = null;
    document.getElementById('customerId').value = '';
    document.getElementById('customerSearch').value = 'Walk-in Customer';
    document.getElementById('customerResults').classList.remove('show');
  });

  // Product search
  const productSearch = document.getElementById('productSearch');
  productSearch.addEventListener('input', ui.debounce(() => {
    searchProducts(productSearch.value);
  }, 300));

  // Sale Details Modal
  document.getElementById('closeSaleDetails').addEventListener('click', () => {
    ui.hideModal('saleDetailsModal');
  });
  document.getElementById('closeSaleDetailsBtn').addEventListener('click', () => {
    ui.hideModal('saleDetailsModal');
  });

  // Print receipt
  document.getElementById('printReceipt').addEventListener('click', printReceipt);

  // Modal outside click
  document.getElementById('newSaleModal').addEventListener('click', (e) => {
    if (e.target.id === 'newSaleModal') closeNewSaleModal();
  });
  document.getElementById('saleDetailsModal').addEventListener('click', (e) => {
    if (e.target.id === 'saleDetailsModal') ui.hideModal('saleDetailsModal');
  });
}

function setDefaultDates() {
  const endDate = new Date();
  const startDate = new Date();
  startDate.setDate(startDate.getDate() - 30);

  document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
  document.getElementById('endDate').value = endDate.toISOString().split('T')[0];
}

async function loadSalesData() {
  try {
    ui.showAlert('Loading sales data...', 'info');

    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const paymentMethod = document.getElementById('paymentFilter').value;

    let url = `/sales?limit=1000`;
    if (startDate) url += `&startDate=${startDate}`;
    if (endDate) url += `&endDate=${endDate}`;
    if (paymentMethod) url += `&paymentMethod=${paymentMethod}`;

    const response = await api.get(url);
    salesData = response.data.sales || [];

    // Calculate summaries
    calculateSummaries();
    renderSalesTable();

    ui.showAlert('Sales data loaded successfully', 'success');
  } catch (error) {
    console.error('Load sales error:', error);
    ui.showAlert('Failed to load sales data', 'error');
  }
}

function calculateSummaries() {
  const today = new Date().toDateString();
  const thisWeekStart = new Date();
  thisWeekStart.setDate(thisWeekStart.getDate() - thisWeekStart.getDay());
  const thisMonthStart = new Date();
  thisMonthStart.setDate(1);

  let todayCount = 0, todayRevenue = 0;
  let weekCount = 0, weekRevenue = 0;
  let monthCount = 0, monthRevenue = 0;
  let totalProfit = 0, totalRevenue = 0;

  salesData.forEach(sale => {
    const saleDate = new Date(sale.sale_date);
    const revenue = parseFloat(sale.total_lrd) || 0;
    const profit = parseFloat(sale.profit) || 0;

    if (saleDate.toDateString() === today) {
      todayCount++;
      todayRevenue += revenue;
    }

    if (saleDate >= thisWeekStart) {
      weekCount++;
      weekRevenue += revenue;
    }

    if (saleDate >= thisMonthStart) {
      monthCount++;
      monthRevenue += revenue;
    }

    totalProfit += profit;
    totalRevenue += revenue;
  });

  document.getElementById('todaySales').textContent = todayCount;
  document.getElementById('todayRevenue').textContent = ui.formatLRD(todayRevenue);
  
  document.getElementById('weekSales').textContent = weekCount;
  document.getElementById('weekRevenue').textContent = ui.formatLRD(weekRevenue);
  
  document.getElementById('monthSales').textContent = monthCount;
  document.getElementById('monthRevenue').textContent = ui.formatLRD(monthRevenue);
  
  document.getElementById('totalProfit').textContent = ui.formatLRD(totalProfit);
  const margin = totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : 0;
  document.getElementById('profitMargin').textContent = `${margin}% Margin`;
}

function renderSalesTable() {
  const tbody = document.getElementById('salesTableBody');
  const totalPages = Math.ceil(salesData.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const pageData = salesData.slice(startIndex, endIndex);

  if (pageData.length === 0) {
    tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">No sales found</td></tr>';
  } else {
    tbody.innerHTML = pageData.map(sale => createSaleRow(sale)).join('');
  }

  // Update pagination
  document.getElementById('currentPage').textContent = currentPage;
  document.getElementById('totalPages').textContent = totalPages || 1;
  document.getElementById('tableInfo').textContent = `Showing ${startIndex + 1}-${Math.min(endIndex, salesData.length)} of ${salesData.length} sales`;

  document.getElementById('prevPage').disabled = currentPage === 1;
  document.getElementById('nextPage').disabled = currentPage === totalPages || totalPages === 0;

  // Add event listeners
  attachSaleActions();
}

function createSaleRow(sale) {
  const paymentClass = `payment-${sale.payment_method}`;
  const profitClass = sale.profit >= 0 ? 'profit-positive' : 'profit-negative';

  return `
    <tr>
      <td><strong>#${sale.id}</strong></td>
      <td>${ui.formatDateTime(sale.sale_date)}</td>
      <td>${sale.customer_name || 'Walk-in'}</td>
      <td>
        <button class="btn btn-sm btn-info view-items-btn" data-id="${sale.id}">
          <i class="fas fa-list"></i> View
        </button>
      </td>
      <td><strong>${ui.formatLRD(sale.total_lrd)}</strong></td>
      <td>
        <span class="payment-badge ${paymentClass}">
          <i class="fas fa-${getPaymentIcon(sale.payment_method)}"></i>
          ${sale.payment_method.replace('_', ' ')}
        </span>
      </td>
      <td class="${profitClass}">
        <strong>${ui.formatLRD(sale.profit)}</strong>
      </td>
      <td>${sale.sold_by_name || 'N/A'}</td>
      <td>
        <button class="btn btn-sm btn-info view-sale-btn" data-id="${sale.id}" title="View Details">
          <i class="fas fa-eye"></i>
        </button>
      </td>
    </tr>
  `;
}

function getPaymentIcon(method) {
  const icons = {
    cash: 'money-bill-wave',
    card: 'credit-card',
    mobile_money: 'mobile-alt',
    credit: 'handshake'
  };
  return icons[method] || 'dollar-sign';
}

function attachSaleActions() {
  document.querySelectorAll('.view-sale-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.dataset.id;
      await viewSaleDetails(id);
    });
  });

  document.querySelectorAll('.view-items-btn').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      const id = e.currentTarget.dataset.id;
      await viewSaleDetails(id);
    });
  });
}

function applyFilters() {
  currentPage = 1;
  loadSalesData();
}

function clearFilters() {
  document.getElementById('paymentFilter').value = '';
  setDefaultDates();
  currentPage = 1;
  loadSalesData();
}

// New Sale Modal Functions
function openNewSaleModal() {
  saleItems = [];
  selectedCustomer = null;
  document.getElementById('newSaleForm').reset();
  document.getElementById('customerId').value = '';
  document.getElementById('customerResults').classList.remove('show');
  document.getElementById('productResults').classList.remove('show');
  updateSaleItemsTable();
  updateSaleSummary();
  ui.showModal('newSaleModal');
}

function closeNewSaleModal() {
  if (saleItems.length > 0) {
    if (!confirm('You have unsaved items. Are you sure you want to close?')) {
      return;
    }
  }
  ui.hideModal('newSaleModal');
}

async function searchCustomers(query) {
  if (!query || query.length < 2) {
    document.getElementById('customerResults').classList.remove('show');
    return;
  }

  // In a real implementation, this would call the API
  // For now, showing placeholder
  const results = document.getElementById('customerResults');
  results.innerHTML = '<div class="search-result-item">Customer search - feature coming soon</div>';
  results.classList.add('show');
}

async function searchProducts(query) {
  if (!query || query.length < 2) {
    document.getElementById('productResults').classList.remove('show');
    return;
  }

  try {
    const response = await api.get(`/stock?search=${encodeURIComponent(query)}&limit=10`);
    const products = response.data.stock || [];

    const results = document.getElementById('productResults');
    
    if (products.length === 0) {
      results.innerHTML = '<div class="search-result-item">No products found</div>';
    } else {
      results.innerHTML = products.map(product => `
        <div class="search-result-item" onclick="addProductToSale(${product.id}, '${escapeHtml(product.product_description)}', ${product.selling_price_lrd}, ${product.buying_price_usd}, ${product.quantity})">
          <div class="result-title">${escapeHtml(product.product_description)}</div>
          <div class="result-details">
            <span>SN: ${product.sn}</span>
            <span>Price: ${ui.formatLRD(product.selling_price_lrd)}</span>
            <span>Stock: ${product.quantity}</span>
          </div>
        </div>
      `).join('');
    }
    
    results.classList.add('show');
  } catch (error) {
    console.error('Search products error:', error);
  }
}

window.addProductToSale = function(id, description, price, cost, availableQty) {
  // Check if already in cart
  const existing = saleItems.find(item => item.id === id);
  if (existing) {
    if (existing.quantity < availableQty) {
      existing.quantity++;
      updateSaleItemsTable();
      updateSaleSummary();
    } else {
      ui.showAlert('Cannot add more than available quantity', 'warning');
    }
  } else {
    saleItems.push({
      id,
      description,
      price,
      cost,
      availableQty,
      quantity: 1
    });
    updateSaleItemsTable();
    updateSaleSummary();
  }

  // Clear search
  document.getElementById('productSearch').value = '';
  document.getElementById('productResults').classList.remove('show');
};

function updateSaleItemsTable() {
  const tbody = document.getElementById('saleItemsBody');

  if (saleItems.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No items added</td></tr>';
    return;
  }

  tbody.innerHTML = saleItems.map((item, index) => `
    <tr>
      <td>
        <strong>${escapeHtml(item.description)}</strong>
      </td>
      <td>${ui.formatLRD(item.price)}</td>
      <td>
        <input 
          type="number" 
          class="form-control quantity-input" 
          value="${item.quantity}" 
          min="1" 
          max="${item.availableQty}"
          onchange="updateItemQuantity(${index}, this.value)"
        >
      </td>
      <td><strong>${ui.formatLRD(item.price * item.quantity)}</strong></td>
      <td>
        <button class="btn btn-sm btn-danger" onclick="removeItem(${index})">
          <i class="fas fa-trash"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

window.updateItemQuantity = function(index, newQty) {
  const qty = parseInt(newQty);
  if (qty > 0 && qty <= saleItems[index].availableQty) {
    saleItems[index].quantity = qty;
    updateSaleSummary();
  } else {
    ui.showAlert('Invalid quantity', 'error');
    updateSaleItemsTable();
  }
};

window.removeItem = function(index) {
  saleItems.splice(index, 1);
  updateSaleItemsTable();
  updateSaleSummary();
};

function updateSaleSummary() {
  const subtotal = saleItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = 0; // No tax for now
  const total = subtotal + tax;
  
  // Calculate profit
  const exchangeRate = 150; // 1 USD = 150 LRD
  const totalCost = saleItems.reduce((sum, item) => {
    return sum + (item.cost * exchangeRate * item.quantity);
  }, 0);
  const profit = total - totalCost;

  document.getElementById('subtotalAmount').textContent = ui.formatLRD(subtotal);
  document.getElementById('taxAmount').textContent = ui.formatLRD(tax);
  document.getElementById('totalAmount').textContent = ui.formatLRD(total);
  document.getElementById('profitAmount').textContent = ui.formatLRD(profit);
}

async function handleSaleSubmit(e) {
  e.preventDefault();

  if (saleItems.length === 0) {
    ui.showAlert('Please add at least one item to the sale', 'error');
    return;
  }

  const paymentMethod = document.getElementById('paymentMethod').value;
  const notes = document.getElementById('saleNotes').value;
  const customerId = document.getElementById('customerId').value || null;

  const saleData = {
    items: saleItems.map(item => ({
      stock_id: item.id,
      quantity: item.quantity
    })),
    customer_id: customerId,
    payment_method: paymentMethod,
    notes: notes
  };

  try {
    document.getElementById('completeSale').disabled = true;
    document.getElementById('completeSale').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';

    const response = await api.post('/sales', saleData);

    ui.showAlert('Sale completed successfully!', 'success');
    closeNewSaleModal();
    await loadSalesData();

    // Optionally show receipt
    if (confirm('Sale completed! Would you like to view the receipt?')) {
      await viewSaleDetails(response.data.saleId);
    }

  } catch (error) {
    console.error('Sale submit error:', error);
    ui.showAlert(error.message || 'Failed to complete sale', 'error');
  } finally {
    document.getElementById('completeSale').disabled = false;
    document.getElementById('completeSale').innerHTML = '<i class="fas fa-check-circle"></i> Complete Sale';
  }
}

async function viewSaleDetails(saleId) {
  try {
    const response = await api.get(`/sales/${saleId}`);
    const sale = response.data;

    const content = document.getElementById('saleDetailsContent');
    content.innerHTML = `
      <div class="sale-detail-section">
        <h4>Sale Information</h4>
        <div class="detail-row">
          <span class="detail-label">Sale ID:</span>
          <span class="detail-value">#${sale.id}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Date & Time:</span>
          <span class="detail-value">${ui.formatDateTime(sale.sale_date)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Customer:</span>
          <span class="detail-value">${sale.customer_name || 'Walk-in Customer'}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Payment Method:</span>
          <span class="detail-value">${sale.payment_method.replace('_', ' ').toUpperCase()}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Sold By:</span>
          <span class="detail-value">${sale.sold_by_name}</span>
        </div>
      </div>

      <div class="sale-detail-section">
        <h4>Items</h4>
        <table class="table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Qty</th>
              <th>Unit Price</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            ${sale.items.map(item => `
              <tr>
                <td>${escapeHtml(item.product_description)}</td>
                <td>${item.quantity}</td>
                <td>${ui.formatLRD(item.unit_price_lrd)}</td>
                <td>${ui.formatLRD(item.subtotal_lrd)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <div class="sale-detail-section">
        <h4>Summary</h4>
        <div class="detail-row">
          <span class="detail-label">Total:</span>
          <span class="detail-value">${ui.formatLRD(sale.total_lrd)}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">Profit:</span>
          <span class="detail-value profit-positive">${ui.formatLRD(sale.profit)}</span>
        </div>
      </div>

      ${sale.notes ? `
        <div class="sale-detail-section">
          <h4>Notes</h4>
          <p>${escapeHtml(sale.notes)}</p>
        </div>
      ` : ''}
    `;

    // Store current sale for printing
    currentSale = sale;
    
    ui.showModal('saleDetailsModal');

  } catch (error) {
    console.error('View sale details error:', error);
    ui.showAlert('Failed to load sale details', 'error');
  }
}

function printReceipt() {
  if (!currentSale) {
    ui.showAlert('No sale selected for printing', 'error');
    return;
  }

  // Create print window
  const printWindow = window.open('', '_blank', 'width=800,height=600');
  
  if (!printWindow) {
    ui.showAlert('Please allow popups to print receipts', 'error');
    return;
  }

  const receiptHTML = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Receipt - Sale #${currentSale.sale_id}</title>
      <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        body {
          font-family: 'Courier New', monospace;
          padding: 20px;
          max-width: 80mm;
          margin: 0 auto;
        }
        .receipt {
          border: 1px dashed #000;
          padding: 15px;
        }
        .header {
          text-align: center;
          margin-bottom: 20px;
          border-bottom: 2px solid #000;
          padding-bottom: 10px;
        }
        .header h1 {
          font-size: 24px;
          margin-bottom: 5px;
        }
        .header p {
          font-size: 12px;
          margin: 2px 0;
        }
        .info {
          margin: 15px 0;
          font-size: 12px;
        }
        .info-row {
          display: flex;
          justify-content: space-between;
          margin: 5px 0;
        }
        .items {
          margin: 15px 0;
        }
        .items table {
          width: 100%;
          border-collapse: collapse;
          font-size: 11px;
        }
        .items th {
          border-bottom: 1px solid #000;
          padding: 5px 0;
          text-align: left;
        }
        .items td {
          padding: 5px 0;
          border-bottom: 1px dashed #ccc;
        }
        .items .qty {
          text-align: center;
          width: 30px;
        }
        .items .price {
          text-align: right;
          width: 80px;
        }
        .total-section {
          margin-top: 15px;
          border-top: 2px solid #000;
          padding-top: 10px;
        }
        .total-row {
          display: flex;
          justify-content: space-between;
          margin: 5px 0;
          font-size: 14px;
        }
        .total-row.grand-total {
          font-weight: bold;
          font-size: 16px;
          margin-top: 10px;
        }
        .footer {
          margin-top: 20px;
          text-align: center;
          font-size: 11px;
          border-top: 1px dashed #000;
          padding-top: 10px;
        }
        @media print {
          body {
            padding: 0;
          }
          .receipt {
            border: none;
          }
          @page {
            margin: 0;
            size: 80mm auto;
          }
        }
      </style>
    </head>
    <body>
      <div class="receipt">
        <div class="header">
          <h1>SmartStock Pharmacy</h1>
          <p>123 Main Street, City</p>
          <p>Tel: +231-XXX-XXXX</p>
          <p>SALES RECEIPT</p>
        </div>

        <div class="info">
          <div class="info-row">
            <span>Receipt #:</span>
            <span><strong>${currentSale.sale_id}</strong></span>
          </div>
          <div class="info-row">
            <span>Date:</span>
            <span>${new Date(currentSale.sale_date).toLocaleString()}</span>
          </div>
          <div class="info-row">
            <span>Customer:</span>
            <span>${escapeHtml(currentSale.customer_name || 'Walk-in Customer')}</span>
          </div>
          <div class="info-row">
            <span>Payment:</span>
            <span>${currentSale.payment_method.replace('_', ' ').toUpperCase()}</span>
          </div>
          <div class="info-row">
            <span>Cashier:</span>
            <span>${escapeHtml(currentSale.sold_by_name)}</span>
          </div>
        </div>

        <div class="items">
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th class="qty">Qty</th>
                <th class="price">Price</th>
                <th class="price">Total</th>
              </tr>
            </thead>
            <tbody>
              ${currentSale.items.map(item => `
                <tr>
                  <td>${escapeHtml(item.product_description)}</td>
                  <td class="qty">${item.quantity}</td>
                  <td class="price">L$${item.unit_price_lrd.toFixed(2)}</td>
                  <td class="price">L$${item.subtotal_lrd.toFixed(2)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>

        <div class="total-section">
          <div class="total-row grand-total">
            <span>TOTAL:</span>
            <span>L$${currentSale.total_lrd.toFixed(2)}</span>
          </div>
        </div>

        ${currentSale.notes ? `
          <div class="info">
            <div class="info-row">
              <span>Notes:</span>
            </div>
            <div style="margin-top: 5px; font-size: 11px;">
              ${escapeHtml(currentSale.notes)}
            </div>
          </div>
        ` : ''}

        <div class="footer">
          <p>Thank you for your business!</p>
          <p>Keep this receipt for your records</p>
          <p>---</p>
          <p style="margin-top: 10px; font-size: 10px;">
            Printed: ${new Date().toLocaleString()}
          </p>
        </div>
      </div>

      <script>
        window.onload = function() {
          window.print();
          // Close window after printing or cancel
          window.onafterprint = function() {
            window.close();
          };
        };
      </script>
    </body>
    </html>
  `;

  printWindow.document.write(receiptHTML);
  printWindow.document.close();
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text).replace(/[&<>"']/g, m => map[m]);
}
