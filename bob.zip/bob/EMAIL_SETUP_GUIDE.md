# Email Service Setup Guide

## Overview
The SmartStock system now includes email functionality for:
- 📧 **Password Reset Emails** - Secure password recovery links
- 👋 **Welcome Emails** - Automatic emails for new user accounts
- ⚠️ **Low Stock Alerts** - Notifications for inventory below reorder level

## Configuration

### Step 1: Update Environment Variables

Edit your `.env` file in the `smartstock-backend` directory and add:

```env
# Email Configuration
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=your-email@gmail.com
EMAIL_PASSWORD=your-app-specific-password
EMAIL_FROM_NAME=SmartStock Pharmacy
```

### Step 2: Email Provider Setup

#### Option A: Gmail (Recommended for Testing)

1. **Enable 2-Factor Authentication**
   - Go to your Google Account settings
   - Navigate to Security → 2-Step Verification
   - Follow the steps to enable 2FA

2. **Generate App-Specific Password**
   - Go to Security → App passwords
   - Select "Mail" and "Other (Custom name)"
   - Name it "SmartStock"
   - Copy the 16-character password
   - Use this password in `EMAIL_PASSWORD`

3. **Update .env file**
   ```env
   EMAIL_HOST=smtp.gmail.com
   EMAIL_PORT=587
   EMAIL_SECURE=false
   EMAIL_USER=your-gmail@gmail.com
   EMAIL_PASSWORD=xxxx xxxx xxxx xxxx
   EMAIL_FROM_NAME=SmartStock Pharmacy
   ```

#### Option B: Other Email Providers

**Microsoft Outlook/Office 365:**
```env
EMAIL_HOST=smtp.office365.com
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=your-email@outlook.com
EMAIL_PASSWORD=your-password
```

**SendGrid (Production Recommended):**
```env
EMAIL_HOST=smtp.sendgrid.net
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=apikey
EMAIL_PASSWORD=your-sendgrid-api-key
```

**Mailgun:**
```env
EMAIL_HOST=smtp.mailgun.org
EMAIL_PORT=587
EMAIL_SECURE=false
EMAIL_USER=your-mailgun-user
EMAIL_PASSWORD=your-mailgun-password
```

### Step 3: Install Dependencies

Run this command in the `smartstock-backend` directory:

```bash
npm install
```

This will install nodemailer along with other dependencies.

### Step 4: Restart the Server

```bash
npm start
# or for development
npm run dev
```

## Testing Email Functionality

### Test Password Reset Email

1. Go to the login page
2. Click "Forgot Password?"
3. Enter a registered email address
4. Check your email inbox for the reset link

**Development Mode:**
- If email is not configured, the reset token will be returned in the API response
- You can manually construct the reset URL

### Test Welcome Email

1. Login as admin
2. Go to Settings → User Management
3. Create a new worker account
4. The new user will receive a welcome email with their credentials

## Email Features

### Password Reset Email
- **Subject:** "Password Reset Request - SmartStock"
- **Contains:**
  - Clickable reset link (expires in 1 hour)
  - User's name
  - Security warnings
  - Copy-paste link option

### Welcome Email
- **Subject:** "Welcome to SmartStock - Account Created"
- **Contains:**
  - User credentials (if provided)
  - Login link
  - Getting started guide
  - Feature highlights

### Low Stock Alert Email
- **Subject:** "⚠️ Low Stock Alert - SmartStock"
- **Contains:**
  - List of items below reorder level
  - Current stock quantities
  - Reorder level thresholds

## Troubleshooting

### Email Not Sending

**Check Console Logs:**
```
Failed to send reset email: Email service not configured
```
**Solution:** Verify all EMAIL_* variables are set in `.env`

**Error: Invalid login:**
```
Error: Invalid login: 535-5.7.8 Username and Password not accepted
```
**Solutions:**
1. Use app-specific password (not your regular password)
2. Enable "Less secure app access" (not recommended)
3. Verify EMAIL_USER and EMAIL_PASSWORD are correct

**Error: Connection timeout:**
```
Error: Connection timeout
```
**Solutions:**
1. Check firewall settings
2. Verify EMAIL_HOST and EMAIL_PORT
3. Try EMAIL_PORT=465 with EMAIL_SECURE=true

### Email Goes to Spam

**For Gmail Users:**
1. Add sender to contacts
2. Mark email as "Not Spam"
3. Use a custom domain (not Gmail) for production

**For Production:**
1. Set up SPF records
2. Set up DKIM signing
3. Set up DMARC policy
4. Use a dedicated email service (SendGrid, Mailgun, etc.)

## Development vs Production

### Development Mode
- Email service is **optional**
- Falls back to console logging
- Returns tokens in API responses for testing

### Production Mode
- Email service is **required**
- No tokens in responses
- Use professional email provider
- Set `NODE_ENV=production` in `.env`

## Security Best Practices

1. **Never commit `.env` file** - It contains sensitive credentials
2. **Use app-specific passwords** - Don't use your main email password
3. **Rotate credentials regularly** - Change passwords periodically
4. **Use environment variables** - Never hardcode credentials
5. **Enable 2FA** - Always use two-factor authentication

## Email Service Options for Production

### Free Tiers (Good for Testing)
- **SendGrid:** 100 emails/day
- **Mailgun:** 100 emails/day  
- **Sendinblue:** 300 emails/day

### Paid Services (Recommended for Production)
- **SendGrid:** Starting at $15/month (40,000 emails)
- **Amazon SES:** $0.10 per 1,000 emails
- **Mailgun:** Starting at $35/month
- **Postmark:** Starting at $15/month

## Optional: Email Template Customization

Email templates are defined in `smartstock-backend/utils/emailService.js`

To customize:
1. Edit the HTML templates in `emailService.js`
2. Update colors, logos, text
3. Add your pharmacy's branding
4. Modify footer information

## Support

If you encounter issues:
1. Check console logs for error messages
2. Verify `.env` configuration
3. Test with Gmail first (easiest setup)
4. Review provider-specific documentation

## What's Next?

Once email is configured, you can:
- ✅ Test password reset functionality
- ✅ Create new users and verify welcome emails
- ✅ Set up automated low stock alerts
- ✅ Configure notification preferences

---

**Note:** Email configuration is **optional** but highly recommended for production use. The system works without email, but users won't be able to reset passwords via email.
