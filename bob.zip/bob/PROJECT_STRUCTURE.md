# SmartStock Pharmacy - Project Structure

## 📁 Complete Directory Tree

```
smartstock-pharmacy/
├── smartstock-backend/          # Backend API (Node.js/Express)
│   ├── config/
│   │   └── db.js               # Database connection configuration
│   ├── database/
│   │   ├── schema.sql          # Database table definitions
│   │   └── seed.sql            # Initial data (categories, suppliers, settings)
│   ├── middleware/
│   │   ├── auth.js             # JWT authentication middleware
│   │   ├── role.js             # RBAC permission checking
│   │   └── validator.js        # Input validation middleware
│   ├── routes/
│   │   ├── auth.js             # Authentication endpoints
│   │   ├── categories.js       # Category management
│   │   ├── dashboard.js        # Dashboard statistics & alerts
│   │   ├── sales.js            # Sales recording & reports
│   │   ├── stock.js            # Stock CRUD & import/export
│   │   ├── suppliers.js        # Supplier management
│   │   └── users.js            # User & permission management
│   ├── scripts/
│   │   └── create-admin.js     # Admin user creation utility
│   ├── uploads/                # CSV upload temporary storage
│   ├── .env.example            # Environment variables template
│   ├── .gitignore             # Git ignore rules
│   ├── package.json           # Node.js dependencies
│   ├── README.md              # Backend documentation
│   └── server.js              # Express server entry point
│
├── smartstock/                 # Frontend (HTML/CSS/JavaScript)
│   ├── css/
│   │   ├── main.css           # Global styles & utilities
│   │   ├── login.css          # Login page styles
│   │   ├── dashboard.css      # Dashboard & navigation styles
│   │   └── stock.css          # Stock management styles
│   ├── js/
│   │   ├── main.js            # Shared utilities (API, auth, UI)
│   │   ├── login.js           # Login page logic
│   │   ├── dashboard.js       # Dashboard data loading & charts
│   │   └── data-management.js # Stock management CRUD
│   ├── uploads/               # File upload storage
│   ├── index.html             # Dashboard page
│   ├── login.html             # Login/authentication page
│   ├── data-management.html   # Stock management page
│   └── inventory.html         # Inventory analysis page (to be created)
│
├── SETUP_GUIDE.md             # Complete installation guide
├── PROJECT_STRUCTURE.md       # This file
└── README.md                  # Project overview
```

---

## 🔧 Backend Components

### Server Configuration
- **server.js**: Main Express application, middleware setup, route mounting
- **config/db.js**: MySQL connection pool with error handling

### Database Layer
- **schema.sql**: Complete database structure (11 tables)
  - users: Authentication & roles
  - user_permissions: RBAC permissions
  - stock: Product inventory
  - categories: Product categorization
  - suppliers: Supplier information
  - sales: Sales transactions
  - sale_items: Individual sale line items
  - customers: Customer records
  - password_reset_tokens: Password recovery
  - audit_log: System activity tracking
  - system_settings: Application configuration

### Middleware
- **auth.js**: JWT token verification, user session validation
- **role.js**: Role-based and module-based permission checking
- **validator.js**: Express-validator error handling

### API Routes

#### Authentication (`/api/auth`)
- `POST /login` - User login with account lockout
- `POST /register` - Create worker accounts (admin only)
- `POST /forgot-password` - Request password reset
- `POST /reset-password` - Reset password with token
- `GET /validate` - Validate JWT token & get permissions

#### Stock Management (`/api/stock`)
- `GET /` - List all stock (with pagination, search, filters)
- `GET /:id` - Get single stock item
- `POST /` - Add new stock item
- `PUT /:id` - Update stock item
- `DELETE /:id` - Soft delete stock item
- `POST /import` - Bulk CSV import

#### Sales (`/api/sales`)
- `GET /` - List sales (with date range filters)
- `GET /:id` - Get sale details with items
- `POST /` - Create new sale (with transaction)
- `GET /reports/summary` - Sales summary report
- `GET /reports/top-products` - Top selling products

#### Dashboard (`/api/dashboard`)
- `GET /stats` - Overall statistics (inventory, sales, profit)
- `GET /alerts` - Low stock, expiring, expired items
- `GET /sales-trend` - Sales trend chart data
- `GET /top-products` - Top 5 selling products
- `GET /category-distribution` - Stock by category

#### User Management (`/api/users`)
- `GET /` - List all users (admin only)
- `GET /:id/permissions` - Get user permissions
- `POST /:id/permissions` - Set user permissions
- `DELETE /:id/permissions/:permissionId` - Remove permission
- `PATCH /:id/status` - Activate/deactivate user
- `POST /:id/reset-password` - Admin password reset
- `POST /:id/unlock` - Unlock locked account

#### Suppliers (`/api/suppliers`)
- `GET /` - List suppliers
- `POST /` - Add supplier
- `PUT /:id` - Update supplier

#### Categories (`/api/categories`)
- `GET /` - List categories
- `POST /` - Add category (admin only)
- `PUT /:id` - Update category (admin only)

---

## 🎨 Frontend Components

### Pages

#### login.html
- Email/password authentication
- Forgot password modal
- Dark mode toggle
- Multi-language selector (EN/FR/ES/PT)
- Remember me functionality

#### index.html (Dashboard)
- Summary cards (total products, stock value, revenue, profit)
- Alert notifications (low stock, expiring, expired)
- Sales trend chart (Chart.js line chart)
- Category distribution (Chart.js doughnut chart)
- Top 5 products table
- Low stock items table

#### data-management.html (Stock Management)
- Advanced search & filters
- Sortable data table
- Pagination (20 items per page)
- Add/Edit stock modal
- CSV import functionality
- Export to CSV
- RBAC-based action visibility

### JavaScript Modules

#### main.js - Core Utilities
**API Module (`api`)**
- `request()` - Base fetch wrapper with auth headers
- `get()`, `post()`, `put()`, `delete()` - HTTP methods
- `upload()` - File upload with FormData

**Auth Module (`auth`)**
- `login()` - Authenticate user
- `logout()` - Clear session
- `getUser()` - Get current user
- `isAuthenticated()` - Check login status
- `validateToken()` - Verify JWT validity
- `hasPermission()` - Check RBAC permissions

**UI Module (`ui`)**
- `showAlert()` - Toast notifications
- `showLoading()`, `hideLoading()` - Loading spinners
- `formatLRD()`, `formatUSD()` - Currency formatting
- `formatDate()`, `formatDateTime()` - Date formatting
- `showModal()`, `hideModal()` - Modal management
- `isValidEmail()`, `isValidPassword()` - Validation
- `debounce()` - Performance optimization

**Dark Mode Module (`darkMode`)**
- `init()`, `enable()`, `disable()`, `toggle()`

**i18n Module (`i18n`)**
- Multi-language support (EN/FR/ES/PT)
- `setLanguage()`, `t()` - Translation functions

#### dashboard.js
- Load dashboard statistics
- Render Chart.js visualizations
- Real-time data updates
- Alert management

#### data-management.js
- Stock CRUD operations
- Client-side filtering & sorting
- Pagination logic
- CSV import/export
- Form validation

### Stylesheets

#### main.css - Design System
- CSS variables for theming
- Dark mode support
- Responsive grid system
- Utility classes
- Common components (cards, buttons, forms, tables, modals)

#### login.css
- Gradient background
- Animated login box
- Password toggle visibility
- Responsive design

#### dashboard.css
- Sticky navigation
- Stat cards with gradients
- Alert container
- Chart containers

#### stock.css
- Search & filter bar
- Sortable table headers
- Action buttons
- Import progress bar

---

## 🔐 Security Features

### Authentication
- JWT-based stateless authentication
- Password hashing with bcrypt (10 rounds)
- Account lockout after 5 failed attempts
- 30-minute session timeout
- Secure password requirements

### Authorization (RBAC)
- Two roles: Admin, Worker
- Module-based permissions (read/write)
- Time-limited permissions
- Admin bypass for all permissions

### API Security
- CORS configuration
- Rate limiting (100 requests/15 min)
- Input validation (express-validator)
- SQL injection prevention (parameterized queries)
- XSS protection (HTML escaping)

### Data Protection
- Environment variables for secrets
- .gitignore for sensitive files
- Audit logging for all actions
- Password reset tokens

---

## 📊 Database Schema

### Key Tables

**users** - System users
- id, email, password, full_name, role, phone
- is_active, login_attempts, locked_until
- two_factor_enabled, two_factor_secret

**stock** - Product inventory
- id, sn, product_description
- buying_price_usd, quantity, selling_price_lrd
- supplier_id, category_id, expiry_date, batch_number
- min_stock_level, is_discontinued

**sales** - Transaction headers
- id, sale_date, customer_id
- total_usd, total_lrd, profit
- payment_method, sold_by

**sale_items** - Transaction details
- id, sale_id, stock_id
- product_sn, quantity
- unit_price_lrd, subtotal_lrd, profit

**user_permissions** - RBAC permissions
- id, user_id, module
- can_read, can_write, expires_at

---

## 🎯 Module Access Matrix

| Module | Admin | Worker (Default) | Worker (Granted) |
|--------|-------|------------------|------------------|
| Dashboard | ✅ Full | ❌ None | ✅ Read/Write |
| Stock | ✅ Full | ❌ None | ✅ Read/Write |
| Inventory | ✅ Full | ❌ None | ✅ Read only |
| Sales | ✅ Full | ❌ None | ✅ Read/Write |
| Reports | ✅ Full | ❌ None | ✅ Read only |
| Users | ✅ Full | ❌ None | ❌ None |
| Settings | ✅ Full | ❌ None | ❌ None |

---

## 🚀 Deployment Considerations

### Production Checklist
- [ ] Change all default passwords
- [ ] Generate secure JWT_SECRET
- [ ] Enable HTTPS/SSL
- [ ] Configure production database
- [ ] Set NODE_ENV=production
- [ ] Enable database backups
- [ ] Configure reverse proxy (nginx)
- [ ] Set up monitoring/logging
- [ ] Implement rate limiting
- [ ] Regular security updates

### Environment Variables
All sensitive configuration in `.env`:
- Database credentials
- JWT secret
- Admin credentials
- API keys
- File upload limits

---

## 📈 Future Enhancements

### Planned Features
- Customer management module
- Supplier performance tracking
- Advanced reporting (PDF export)
- Email notifications
- Mobile app (React Native)
- Barcode scanning
- Multi-branch support
- Accounting integration
- Real-time notifications (WebSocket)
- Two-factor authentication

---

This structure provides a solid foundation for a complete pharmacy management system with enterprise-level security and scalability.
