# 🏥 SmartStock Pharmacy Management System

**Professional Inventory & Sales Management for Boystown Pharmacy**

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Node.js](https://img.shields.io/badge/Node.js-16.x+-green.svg)](https://nodejs.org/)
[![MySQL](https://img.shields.io/badge/MySQL-8.x-blue.svg)](https://www.mysql.com/)

---

## 📋 Overview

SmartStock is a comprehensive pharmacy management system designed specifically for Boystown Pharmacy. It provides real-time inventory tracking, sales management, profit analysis, and role-based access control to streamline pharmacy operations.

### ✨ Key Features

- **📊 Real-time Dashboard**: Live statistics, sales trends, and inventory alerts
- **📦 Stock Management**: Complete CRUD operations with CSV import/export
- **🔍 Inventory Analysis**: Fast/slow-moving items, expiring products, reorder recommendations
- **💰 Sales Tracking**: Transaction recording with automatic profit calculations
- **👥 RBAC System**: Granular permissions for admin and worker roles
- **🌙 Dark Mode**: Eye-friendly dark theme support
- **🌍 Multi-language**: Support for English, French, Spanish, Portuguese
- **📱 Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **🔒 Security First**: JWT authentication, password hashing, account lockout

---

## 🚀 Quick Start

### Prerequisites

- **Node.js** v16.x or higher
- **MySQL** v8.x or higher
- **Modern Web Browser** (Chrome, Firefox, Edge, Safari)

### Installation

```bash
# 1. Install backend dependencies
cd smartstock-backend
npm install

# 2. Set up database
mysql -u root -p < database/schema.sql
mysql -u root -p smartstock_db < database/seed.sql

# 3. Configure environment
cp .env.example .env
# Edit .env with your database credentials

# 4. Create admin user
node scripts/create-admin.js

# 5. Start backend server
npm start
# Backend runs on http://localhost:3000

# 6. Start frontend server (in new terminal)
cd ../smartstock
http-server -p 8080
# Frontend runs on http://localhost:8080
```

### First Login

1. Navigate to `http://localhost:8080/login.html`
2. Login with default credentials:
   - **Email**: `admin@boystown.com`
   - **Password**: `Admin@123`
3. **Important**: Change the password immediately after first login!

---

## 📁 Project Structure

```
smartstock-pharmacy/
├── smartstock-backend/      # Node.js/Express API
│   ├── config/             # Database configuration
│   ├── database/           # SQL schemas and seeds
│   ├── middleware/         # Auth, RBAC, validation
│   ├── routes/             # API endpoints
│   ├── scripts/            # Utility scripts
│   └── server.js           # Express server
│
├── smartstock/             # Frontend (HTML/CSS/JS)
│   ├── css/               # Stylesheets
│   ├── js/                # JavaScript modules
│   ├── index.html         # Dashboard
│   ├── login.html         # Authentication
│   ├── data-management.html  # Stock management
│   └── inventory.html     # Inventory analysis
│
├── SETUP_GUIDE.md         # Detailed setup instructions
├── PROJECT_STRUCTURE.md   # Complete documentation
└── README.md              # This file
```

---

## 🎯 Core Modules

### 1. Authentication & Security
- User login with email/password
- JWT token-based sessions
- Account lockout after failed attempts
- Password reset functionality
- 2FA support for admin accounts

### 2. Dashboard
- Real-time inventory statistics
- Today's sales and profit
- Low stock alerts
- Expiring product warnings
- Sales trend charts
- Top-selling products

### 3. Stock Management
- Add, edit, delete stock items
- Advanced search and filtering
- Sortable data tables
- Bulk CSV import
- Export to CSV
- Barcode/batch number tracking

### 4. Inventory Analysis
- Stock value by category
- Fast-moving products (top 25%)
- Slow-moving products (bottom 25%)
- No-sale items (90+ days)
- Expiring soon (<30 days)
- Reorder recommendations

### 5. Sales Management *(In Progress)*
- Quick sale recording
- Customer tracking
- Payment methods
- Sales reports
- Profit analysis

### 6. User & Permission Management *(Admin Only)*
- Create worker accounts
- Assign module permissions
- Time-limited access
- Audit logging

---

## 🔐 Security Features

### Authentication
- **bcrypt** password hashing (10 rounds)
- **JWT** tokens with 30-minute expiration
- Account lockout after 5 failed login attempts
- Secure password requirements (8+ chars, mixed case, numbers, symbols)

### Authorization (RBAC)
- **Admin Role**: Full system access
- **Worker Role**: Permission-based access to modules
- **Module Permissions**: Read/Write granularity
- **Time-limited**: Permissions can expire

### API Security
- CORS configuration
- Rate limiting (100 req/15 min)
- Input validation
- SQL injection prevention
- XSS protection

---

## 📊 Data Integration

### Boystown Pharmacy Data
- **157 Stock Items** ready for import
- **Total Value**: $1,916.75 USD
- **Estimated Revenue**: $4,683.32 USD
- **Profit Margin**: 59.1%

### CSV Import Format
```csv
sn,product_description,buying_price_usd,quantity,selling_price_lrd,supplier_id,category_id,expiry_date,batch_number,min_stock_level
1,Paracetamol 500mg,2.50,100,450,1,1,2025-12-31,BATCH001,10
```

---

## 🎨 UI/UX Design

### Color Palette
- **Primary Green**: #28a745 (Actions, Success)
- **Primary Blue**: #007bff (Information)
- **Error Red**: #dc3545 (Errors, Urgent)
- **Warning Yellow**: #ffc107 (Caution)
- **Dark Mode**: #1a3c34 (Dark theme)

### Typography
- **Headers**: Lora (Serif)
- **Body**: Open Sans (Sans-serif)
- **Navigation**: Roboto (Clean)

### Icons
- Font Awesome 6.4.0
- Chart.js for visualizations

---

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - Create worker (admin only)
- `GET /api/auth/validate` - Validate token

### Stock
- `GET /api/stock` - List all stock
- `POST /api/stock` - Add stock item
- `PUT /api/stock/:id` - Update stock
- `DELETE /api/stock/:id` - Delete stock
- `POST /api/stock/import` - CSV import

### Sales
- `GET /api/sales` - List sales
- `POST /api/sales` - Create sale
- `GET /api/sales/reports/summary` - Sales report

### Dashboard
- `GET /api/dashboard/stats` - Statistics
- `GET /api/dashboard/alerts` - Alerts
- `GET /api/dashboard/top-products` - Top sellers

Full API documentation in [API_REFERENCE.md](./API_REFERENCE.md)

---

## 🚀 Deployment

### Production Checklist

- [ ] Change all default passwords
- [ ] Generate secure `JWT_SECRET` (32+ chars)
- [ ] Set `NODE_ENV=production`
- [ ] Enable HTTPS/SSL
- [ ] Configure production database
- [ ] Set up database backups
- [ ] Configure reverse proxy (nginx)
- [ ] Enable monitoring/logging
- [ ] Review CORS settings
- [ ] Set up email notifications

### Recommended Hosting
- **Backend**: DigitalOcean, Heroku, AWS EC2
- **Database**: AWS RDS, DigitalOcean Managed MySQL
- **Frontend**: Netlify, Vercel, GitHub Pages

---

## 📈 Performance Metrics

### Target Metrics
- ✅ Page load time < 3 seconds
- ✅ API response time < 500ms
- ✅ Mobile-responsive design
- ✅ Cross-browser compatibility
- ✅ 99% uptime target

### Current Status
- **Backend**: Fully functional ✅
- **Frontend**: 3 core modules complete ✅
- **Authentication**: Complete with RBAC ✅
- **Database**: 11 tables, optimized indexes ✅

---

## 🛠️ Technology Stack

### Backend
- **Runtime**: Node.js 16+
- **Framework**: Express.js
- **Database**: MySQL 8
- **Authentication**: JWT + bcrypt
- **Validation**: express-validator
- **File Upload**: Multer
- **CSV Processing**: csv-parser

### Frontend
- **Structure**: HTML5
- **Styling**: CSS3 with custom variables
- **Scripting**: Vanilla JavaScript (ES6+)
- **Charts**: Chart.js 4.4.0
- **Icons**: Font Awesome 6.4.0
- **Fonts**: Google Fonts (Lora, Open Sans, Roboto)

---

## 📝 Development Roadmap

### Phase 1: Foundation ✅ (Week 1)
- [x] Project structure
- [x] Database schema
- [x] Authentication system
- [x] Login page

### Phase 2: Core Modules ✅ (Week 2)
- [x] Dashboard with real data
- [x] Stock management CRUD
- [x] RBAC implementation
- [x] Inventory analysis

### Phase 3: Advanced Features (Week 3)
- [ ] Sales recording interface
- [ ] Customer management
- [ ] Supplier tracking
- [ ] Advanced reports

### Phase 4: Polish & Deploy (Week 4)
- [ ] Admin settings panel
- [ ] Email notifications
- [ ] PDF report generation
- [ ] Mobile app (React Native)
- [ ] Testing & optimization

---

## 🤝 Contributing

This is a custom project for Boystown Pharmacy. For feature requests or bug reports, please contact the development team.

---

## 📄 License

MIT License - See [LICENSE](./LICENSE) file for details

---

## 📞 Support

### Documentation
- [Setup Guide](./SETUP_GUIDE.md) - Complete installation instructions
- [Project Structure](./PROJECT_STRUCTURE.md) - Detailed architecture
- [API Reference](./API_REFERENCE.md) - Full API documentation

### Contact
For technical support or inquiries about SmartStock Pharmacy:
- **Email**: support@boystown.com
- **Phone**: +231-XXX-XXXX

---

## 🎉 Acknowledgments

- **Boystown Pharmacy** - For the opportunity to build this system
- **Open Source Community** - For the amazing tools and libraries
- **Node.js & MySQL** - For robust and reliable technology

---

**Built with ❤️ for Boystown Pharmacy**

*SmartStock - Simplifying Pharmacy Management, One Click at a Time*
