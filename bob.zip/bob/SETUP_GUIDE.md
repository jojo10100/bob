# SmartStock Pharmacy - Complete Setup Guide

## 📋 Table of Contents
1. [System Requirements](#system-requirements)
2. [Installation Steps](#installation-steps)
3. [Database Setup](#database-setup)
4. [Backend Configuration](#backend-configuration)
5. [Frontend Setup](#frontend-setup)
6. [Running the Application](#running-the-application)
7. [Default Credentials](#default-credentials)
8. [Troubleshooting](#troubleshooting)

---

## 🖥️ System Requirements

- **Node.js**: v16.x or higher
- **MySQL**: v8.x or higher
- **Web Browser**: Chrome, Firefox, Edge, or Safari (latest version)
- **Operating System**: Windows, macOS, or Linux

---

## 📦 Installation Steps

### Step 1: Install Node.js
1. Download Node.js from https://nodejs.org/
2. Run the installer and follow the prompts
3. Verify installation:
   ```bash
   node --version
   npm --version
   ```

### Step 2: Install MySQL
1. Download MySQL from https://dev.mysql.com/downloads/mysql/
2. Install MySQL Server
3. Set root password during installation
4. Start MySQL service

### Step 3: Install Backend Dependencies
```bash
cd smartstock-backend
npm install
```

This will install:
- express (Web framework)
- mysql2 (Database driver)
- bcryptjs (Password hashing)
- jsonwebtoken (Authentication)
- dotenv (Environment variables)
- cors (Cross-origin resource sharing)
- express-validator (Input validation)
- multer (File uploads)
- csv-parser (CSV processing)
- express-rate-limit (Rate limiting)

---

## 🗄️ Database Setup

### Step 1: Create Database
1. Open MySQL command line or MySQL Workbench
2. Run the following command:
   ```sql
   CREATE DATABASE smartstock_db;
   ```

### Step 2: Create Tables
Execute the SQL script located at:
```
smartstock-backend/database/schema.sql
```

**Using MySQL Command Line:**
```bash
mysql -u root -p smartstock_db < smartstock-backend/database/schema.sql
```

**Using MySQL Workbench:**
1. Open MySQL Workbench
2. Connect to your MySQL server
3. Open the `schema.sql` file
4. Execute the script

### Step 3: Insert Initial Data
Execute the seed data script:
```bash
mysql -u root -p smartstock_db < smartstock-backend/database/seed.sql
```

### Step 4: Create Admin User
Since bcrypt hashing requires the app to be running, we'll create the admin user after starting the server for the first time.

---

## ⚙️ Backend Configuration

### Step 1: Create Environment File
1. Navigate to `smartstock-backend` folder
2. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

### Step 2: Configure .env File
Open the `.env` file and update the following:

```env
# Server Configuration
PORT=3000
NODE_ENV=development

# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password_here
DB_NAME=smartstock_db
DB_PORT=3306

# JWT Configuration (IMPORTANT: Change this to a random string)
JWT_SECRET=your_super_secret_jwt_key_change_this_to_random_string_min_32_chars
JWT_EXPIRES_IN=30m
JWT_REFRESH_EXPIRES_IN=7d

# Admin Account (Default credentials - change after first login)
ADMIN_EMAIL=admin@boystown.com
ADMIN_PASSWORD=Admin@123

# Security
MAX_LOGIN_ATTEMPTS=5
LOCKOUT_DURATION=900000

# Frontend URL (CORS)
FRONTEND_URL=http://localhost:8080

# File Upload
MAX_FILE_SIZE=5242880
```

**Important Security Notes:**
- Change `JWT_SECRET` to a long random string (minimum 32 characters)
- Use a strong admin password
- Never commit the `.env` file to version control

### Step 3: Generate Admin Password Hash
1. Start the backend server (see Running the Application)
2. Open your browser and go to: `http://localhost:3000/health`
3. If successful, stop the server (Ctrl+C)
4. Run this script to create the admin user:

**Create a file: `smartstock-backend/scripts/create-admin.js`**
```javascript
require('dotenv').config();
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

async function createAdmin() {
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
  });

  const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin@123', 10);
  
  await connection.query(
    'INSERT INTO users (email, password, full_name, role) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE password = ?',
    [process.env.ADMIN_EMAIL, hashedPassword, 'System Administrator', 'admin', hashedPassword]
  );

  console.log('✅ Admin user created successfully!');
  console.log(`Email: ${process.env.ADMIN_EMAIL}`);
  console.log(`Password: ${process.env.ADMIN_PASSWORD}`);
  
  await connection.end();
}

createAdmin().catch(console.error);
```

**Run the script:**
```bash
node scripts/create-admin.js
```

---

## 🌐 Frontend Setup

### Step 1: Install HTTP Server
The frontend is pure HTML/CSS/JavaScript and needs a simple HTTP server.

**Option 1: Using http-server (Recommended)**
```bash
npm install -g http-server
```

**Option 2: Using Python**
```bash
# Python 3
python -m http.server 8080

# Python 2
python -m SimpleHTTPServer 8080
```

**Option 3: Using VS Code Live Server**
1. Install "Live Server" extension in VS Code
2. Right-click on `login.html`
3. Select "Open with Live Server"

### Step 2: No Additional Configuration Needed
The frontend automatically connects to `http://localhost:3000/api` (backend).

---

## 🚀 Running the Application

### Start Backend Server

**Development Mode (with auto-reload):**
```bash
cd smartstock-backend
npm run dev
```

**Production Mode:**
```bash
cd smartstock-backend
npm start
```

The backend will start on `http://localhost:3000`

### Start Frontend Server

**Using http-server:**
```bash
cd smartstock
http-server -p 8080
```

**Using Python:**
```bash
cd smartstock
python -m http.server 8080
```

The frontend will be available at `http://localhost:8080`

### Verify Both Servers Are Running

1. **Backend Health Check:**
   - Open browser: `http://localhost:3000/health`
   - Should show: `{"status":"OK","message":"SmartStock API is running"}`

2. **Frontend Check:**
   - Open browser: `http://localhost:8080/login.html`
   - Should show the login page

---

## 🔑 Default Credentials

**Admin Account:**
- Email: `admin@boystown.com`
- Password: `Admin@123`

**⚠️ IMPORTANT:** Change the admin password immediately after first login!

---

## 📊 Importing Your Stock Data

### Step 1: Prepare CSV File
Create a CSV file with the following columns:
```
sn,product_description,buying_price_usd,quantity,selling_price_lrd,supplier_id,category_id,expiry_date,batch_number,min_stock_level
```

**Example:**
```csv
1,Paracetamol 500mg,2.50,100,450,1,1,2025-12-31,BATCH001,10
2,Amoxicillin 250mg,5.00,50,900,1,1,2026-03-15,BATCH002,10
```

### Step 2: Import via Web Interface
1. Login to SmartStock
2. Go to "Stock Management"
3. Click "Import CSV"
4. Select your CSV file
5. Click "Import"

### Step 3: Verify Import
Check the stock table to ensure all items were imported correctly.

---

## 🔧 Troubleshooting

### Backend Won't Start

**Error: "Cannot connect to database"**
- Verify MySQL is running
- Check database credentials in `.env`
- Ensure database `smartstock_db` exists

**Error: "Port 3000 already in use"**
- Change `PORT` in `.env` to another port (e.g., 3001)
- Or kill the process using port 3000

**Error: "Module not found"**
- Run `npm install` in `smartstock-backend` folder

### Frontend Issues

**Cannot load login page**
- Verify http-server is running
- Check console for errors (F12 in browser)
- Ensure you're accessing `http://localhost:8080/login.html`

**Login fails with "Network Error"**
- Verify backend is running (`http://localhost:3000/health`)
- Check CORS settings in backend
- Verify `API_BASE_URL` in `smartstock/js/main.js`

**CORS Errors**
- Update `FRONTEND_URL` in backend `.env`
- Restart backend server

### Database Issues

**Tables don't exist**
- Re-run `schema.sql`
- Check MySQL error logs

**Foreign key constraints**
- Ensure tables are created in correct order
- Check that referenced IDs exist

---

## 📱 Browser Compatibility

**Supported Browsers:**
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Edge 90+
- ✅ Safari 14+

**Not Supported:**
- ❌ Internet Explorer

---

## 🔒 Security Best Practices

1. **Change Default Credentials**
   - Change admin password after first login
   - Use strong passwords (min 8 chars, uppercase, lowercase, numbers, symbols)

2. **Secure JWT Secret**
   - Generate a random string for `JWT_SECRET`
   - Never commit `.env` to version control

3. **HTTPS in Production**
   - Use SSL certificate for production
   - Configure reverse proxy (nginx/Apache)

4. **Regular Backups**
   - Backup database regularly
   - Export stock data weekly

5. **Update Dependencies**
   - Run `npm audit` regularly
   - Update packages: `npm update`

---

## 📞 Support

For issues or questions:
- Check the troubleshooting section
- Review error logs in browser console (F12)
- Check backend logs in terminal

---

## 🎉 Next Steps

After successful setup:

1. **Login** with admin credentials
2. **Change admin password** in Settings
3. **Create worker accounts** for staff
4. **Configure categories** and suppliers
5. **Import your stock data**
6. **Set up RBAC permissions** for workers
7. **Start managing your pharmacy!**

---

**Congratulations! Your SmartStock Pharmacy Management System is ready to use!** 🚀
