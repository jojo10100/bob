const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');
const { validate } = require('../middleware/validator');

// Get all categories
router.get('/', authenticateToken, async (req, res) => {
  try {
    const [categories] = await db.query('SELECT * FROM categories ORDER BY name ASC');

    res.json({
      success: true,
      data: categories
    });

  } catch (error) {
    console.error('Get categories error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve categories'
    });
  }
});

// Add new category (Admin only)
router.post('/', [
  authenticateToken,
  requireRole('admin'),
  body('name').notEmpty().withMessage('Category name is required'),
  validate
], async (req, res) => {
  try {
    const { name, description } = req.body;

    const [result] = await db.query(
      'INSERT INTO categories (name, description) VALUES (?, ?)',
      [name, description || null]
    );

    res.status(201).json({
      success: true,
      message: 'Category added successfully',
      data: { id: result.insertId }
    });

  } catch (error) {
    console.error('Add category error:', error);
    
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({
        success: false,
        message: 'Category name already exists'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to add category'
    });
  }
});

// Update category (Admin only)
router.put('/:id', [
  authenticateToken,
  requireRole('admin'),
  validate
], async (req, res) => {
  try {
    const { id } = req.params;
    const { name, description } = req.body;

    const updateFields = [];
    const updateValues = [];

    if (name) {
      updateFields.push('name = ?');
      updateValues.push(name);
    }

    if (description !== undefined) {
      updateFields.push('description = ?');
      updateValues.push(description);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    updateValues.push(id);

    await db.query(
      `UPDATE categories SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    res.json({
      success: true,
      message: 'Category updated successfully'
    });

  } catch (error) {
    console.error('Update category error:', error);
    
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({
        success: false,
        message: 'Category name already exists'
      });
    }

    res.status(500).json({
      success: false,
      message: 'Failed to update category'
    });
  }
});

module.exports = router;
