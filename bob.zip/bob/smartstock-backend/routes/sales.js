const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requirePermission } = require('../middleware/role');
const { validate } = require('../middleware/validator');

// Get all sales
router.get('/', authenticateToken, requirePermission('sales', 'read'), async (req, res) => {
  try {
    const {
      startDate,
      endDate,
      soldBy,
      customer,
      page = 1,
      limit = 20
    } = req.query;

    let query = `
      SELECT s.*, 
             c.name as customer_name,
             u.full_name as sold_by_name
      FROM sales s
      LEFT JOIN customers c ON s.customer_id = c.id
      LEFT JOIN users u ON s.sold_by = u.id
      WHERE 1=1
    `;

    const params = [];

    // Date range filter
    if (startDate) {
      query += ` AND s.sale_date >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND s.sale_date <= ?`;
      params.push(endDate);
    }

    // Sold by filter
    if (soldBy) {
      query += ` AND s.sold_by = ?`;
      params.push(soldBy);
    }

    // Customer filter
    if (customer) {
      query += ` AND s.customer_id = ?`;
      params.push(customer);
    }

    // Count total records
    const countQuery = query.replace(/SELECT s\.\*.*FROM/, 'SELECT COUNT(*) as total FROM');
    const [countResult] = await db.query(countQuery, params);
    const totalRecords = countResult[0].total;

    // Add pagination
    query += ` ORDER BY s.sale_date DESC LIMIT ? OFFSET ?`;
    const offset = (page - 1) * limit;
    params.push(parseInt(limit), parseInt(offset));

    const [sales] = await db.query(query, params);

    res.json({
      success: true,
      data: {
        sales,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(totalRecords / limit),
          totalRecords,
          recordsPerPage: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Get sales error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve sales'
    });
  }
});

// Get single sale with items
router.get('/:id', authenticateToken, requirePermission('sales', 'read'), async (req, res) => {
  try {
    const [sale] = await db.query(
      `SELECT s.*, 
              c.name as customer_name,
              u.full_name as sold_by_name
       FROM sales s
       LEFT JOIN customers c ON s.customer_id = c.id
       LEFT JOIN users u ON s.sold_by = u.id
       WHERE s.id = ?`,
      [req.params.id]
    );

    if (sale.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Sale not found'
      });
    }

    // Get sale items
    const [items] = await db.query(
      'SELECT * FROM sale_items WHERE sale_id = ?',
      [req.params.id]
    );

    res.json({
      success: true,
      data: {
        ...sale[0],
        items
      }
    });

  } catch (error) {
    console.error('Get sale error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve sale'
    });
  }
});

// Create new sale
router.post('/', [
  authenticateToken,
  requirePermission('sales', 'write'),
  body('items').isArray({ min: 1 }).withMessage('At least one item is required'),
  body('items.*.stock_id').isInt().withMessage('Valid stock ID is required'),
  body('items.*.quantity').isInt({ min: 1 }).withMessage('Valid quantity is required'),
  body('payment_method').isIn(['cash', 'card', 'mobile_money', 'credit']).withMessage('Valid payment method is required'),
  validate
], async (req, res) => {
  const connection = await db.getConnection();
  
  try {
    await connection.beginTransaction();

    const {
      items,
      customer_id,
      payment_method,
      notes
    } = req.body;

    let totalLRD = 0;
    let totalUSD = 0;
    let totalProfit = 0;

    // Validate all items and calculate totals
    for (const item of items) {
      const [stock] = await connection.query(
        'SELECT * FROM stock WHERE id = ? AND is_discontinued = FALSE',
        [item.stock_id]
      );

      if (stock.length === 0) {
        throw new Error(`Stock item ${item.stock_id} not found`);
      }

      if (stock[0].quantity < item.quantity) {
        throw new Error(`Insufficient stock for ${stock[0].product_description}`);
      }

      const subtotalLRD = stock[0].selling_price_lrd * item.quantity;
      const subtotalUSD = stock[0].buying_price_usd * item.quantity;
      const profit = subtotalLRD - (subtotalUSD * 150); // Assuming 150 LRD = 1 USD

      totalLRD += subtotalLRD;
      totalUSD += subtotalUSD;
      totalProfit += profit;

      item.stockData = stock[0];
      item.subtotalLRD = subtotalLRD;
      item.profit = profit;
    }

    // Create sale record
    const [saleResult] = await connection.query(
      `INSERT INTO sales (customer_id, total_usd, total_lrd, profit, payment_method, sold_by, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [customer_id || null, totalUSD, totalLRD, totalProfit, payment_method, req.user.userId, notes || null]
    );

    const saleId = saleResult.insertId;

    // Create sale items and update stock
    for (const item of items) {
      // Insert sale item
      await connection.query(
        `INSERT INTO sale_items (
          sale_id, stock_id, product_sn, product_description, quantity,
          unit_price_lrd, unit_cost_usd, subtotal_lrd, profit
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          saleId,
          item.stock_id,
          item.stockData.sn,
          item.stockData.product_description,
          item.quantity,
          item.stockData.selling_price_lrd,
          item.stockData.buying_price_usd,
          item.subtotalLRD,
          item.profit
        ]
      );

      // Update stock quantity
      await connection.query(
        'UPDATE stock SET quantity = quantity - ? WHERE id = ?',
        [item.quantity, item.stock_id]
      );
    }

    // Log action
    await connection.query(
      'INSERT INTO audit_log (user_id, action, table_name, record_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'CREATE_SALE', 'sales', saleId]
    );

    await connection.commit();

    res.status(201).json({
      success: true,
      message: 'Sale recorded successfully',
      data: {
        saleId,
        totalLRD,
        totalUSD,
        totalProfit
      }
    });

  } catch (error) {
    await connection.rollback();
    console.error('Create sale error:', error);
    res.status(500).json({
      success: false,
      message: error.message || 'Failed to create sale'
    });
  } finally {
    connection.release();
  }
});

// Get sales report
router.get('/reports/summary', authenticateToken, requirePermission('sales', 'read'), async (req, res) => {
  try {
    const { startDate, endDate, groupBy = 'day' } = req.query;

    let dateFormat;
    switch (groupBy) {
      case 'month':
        dateFormat = '%Y-%m';
        break;
      case 'year':
        dateFormat = '%Y';
        break;
      default:
        dateFormat = '%Y-%m-%d';
    }

    let query = `
      SELECT 
        DATE_FORMAT(sale_date, ?) as period,
        COUNT(*) as total_sales,
        SUM(total_lrd) as total_revenue_lrd,
        SUM(total_usd) as total_cost_usd,
        SUM(profit) as total_profit,
        AVG(profit) as avg_profit
      FROM sales
      WHERE 1=1
    `;

    const params = [dateFormat];

    if (startDate) {
      query += ` AND sale_date >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND sale_date <= ?`;
      params.push(endDate);
    }

    query += ` GROUP BY period ORDER BY period DESC`;

    const [report] = await db.query(query, params);

    res.json({
      success: true,
      data: report
    });

  } catch (error) {
    console.error('Sales report error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate report'
    });
  }
});

// Get top selling products
router.get('/reports/top-products', authenticateToken, requirePermission('sales', 'read'), async (req, res) => {
  try {
    const { limit = 10, startDate, endDate } = req.query;

    let query = `
      SELECT 
        si.product_sn,
        si.product_description,
        SUM(si.quantity) as total_quantity_sold,
        SUM(si.subtotal_lrd) as total_revenue,
        SUM(si.profit) as total_profit,
        COUNT(DISTINCT si.sale_id) as number_of_sales
      FROM sale_items si
      JOIN sales s ON si.sale_id = s.id
      WHERE 1=1
    `;

    const params = [];

    if (startDate) {
      query += ` AND s.sale_date >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND s.sale_date <= ?`;
      params.push(endDate);
    }

    query += ` GROUP BY si.product_sn, si.product_description`;
    query += ` ORDER BY total_quantity_sold DESC LIMIT ?`;
    params.push(parseInt(limit));

    const [products] = await db.query(query, params);

    res.json({
      success: true,
      data: products
    });

  } catch (error) {
    console.error('Top products report error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate report'
    });
  }
});

module.exports = router;
