const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requirePermission } = require('../middleware/role');
const { validate } = require('../middleware/validator');
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');

// Configure multer for CSV upload
const upload = multer({ dest: 'uploads/' });

// Get all stock items
router.get('/', authenticateToken, requirePermission('stock', 'read'), async (req, res) => {
  try {
    const { 
      search, 
      category, 
      supplier,
      lowStock,
      expiringSoon,
      page = 1, 
      limit = 20,
      sortBy = 'product_description',
      sortOrder = 'ASC'
    } = req.query;

    let query = `
      SELECT s.*, 
             c.name as category_name,
             sup.name as supplier_name,
             u.full_name as created_by_name
      FROM stock s
      LEFT JOIN categories c ON s.category_id = c.id
      LEFT JOIN suppliers sup ON s.supplier_id = sup.id
      LEFT JOIN users u ON s.created_by = u.id
      WHERE s.is_discontinued = FALSE
    `;

    const params = [];

    // Search filter
    if (search) {
      query += ` AND (s.sn LIKE ? OR s.product_description LIKE ? OR s.batch_number LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    // Category filter
    if (category) {
      query += ` AND s.category_id = ?`;
      params.push(category);
    }

    // Supplier filter
    if (supplier) {
      query += ` AND s.supplier_id = ?`;
      params.push(supplier);
    }

    // Low stock filter
    if (lowStock === 'true') {
      query += ` AND s.quantity <= s.min_stock_level`;
    }

    // Expiring soon filter (next 30 days)
    if (expiringSoon === 'true') {
      query += ` AND s.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)`;
    }

    // Count total records
    const countQuery = query.replace(/SELECT s\.\*.*FROM/, 'SELECT COUNT(*) as total FROM');
    const [countResult] = await db.query(countQuery, params);
    const totalRecords = countResult[0].total;

    // Add sorting and pagination
    const validSortColumns = ['sn', 'product_description', 'quantity', 'selling_price_lrd', 'expiry_date'];
    const sortColumn = validSortColumns.includes(sortBy) ? sortBy : 'product_description';
    const order = sortOrder.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    query += ` ORDER BY s.${sortColumn} ${order}`;
    query += ` LIMIT ? OFFSET ?`;

    const offset = (page - 1) * limit;
    params.push(parseInt(limit), parseInt(offset));

    const [stock] = await db.query(query, params);

    res.json({
      success: true,
      data: {
        stock,
        pagination: {
          currentPage: parseInt(page),
          totalPages: Math.ceil(totalRecords / limit),
          totalRecords,
          recordsPerPage: parseInt(limit)
        }
      }
    });

  } catch (error) {
    console.error('Get stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve stock'
    });
  }
});

// Get single stock item
router.get('/:id', authenticateToken, requirePermission('stock', 'read'), async (req, res) => {
  try {
    const [stock] = await db.query(
      `SELECT s.*, 
              c.name as category_name,
              sup.name as supplier_name,
              u.full_name as created_by_name
       FROM stock s
       LEFT JOIN categories c ON s.category_id = c.id
       LEFT JOIN suppliers sup ON s.supplier_id = sup.id
       LEFT JOIN users u ON s.created_by = u.id
       WHERE s.id = ?`,
      [req.params.id]
    );

    if (stock.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Stock item not found'
      });
    }

    res.json({
      success: true,
      data: stock[0]
    });

  } catch (error) {
    console.error('Get stock item error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve stock item'
    });
  }
});

// Add new stock item
router.post('/', [
  authenticateToken,
  requirePermission('stock', 'write'),
  body('sn').notEmpty().withMessage('Product SN is required'),
  body('product_description').notEmpty().withMessage('Product description is required'),
  body('buying_price_usd').isFloat({ min: 0 }).withMessage('Valid buying price is required'),
  body('quantity').isInt({ min: 0 }).withMessage('Valid quantity is required'),
  body('selling_price_lrd').isFloat({ min: 0 }).withMessage('Valid selling price is required'),
  validate
], async (req, res) => {
  try {
    const {
      sn,
      product_description,
      buying_price_usd,
      quantity,
      selling_price_lrd,
      supplier_id,
      category_id,
      expiry_date,
      batch_number,
      min_stock_level
    } = req.body;

    // Check if SN already exists
    const [existing] = await db.query('SELECT id FROM stock WHERE sn = ?', [sn]);
    
    if (existing.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Product SN already exists'
      });
    }

    const [result] = await db.query(
      `INSERT INTO stock (
        sn, product_description, buying_price_usd, quantity, selling_price_lrd,
        supplier_id, category_id, expiry_date, batch_number, min_stock_level, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        sn, product_description, buying_price_usd, quantity, selling_price_lrd,
        supplier_id || null, category_id || null, expiry_date || null,
        batch_number || null, min_stock_level || 10, req.user.userId
      ]
    );

    // Log action
    await db.query(
      'INSERT INTO audit_log (user_id, action, table_name, record_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'ADD_STOCK', 'stock', result.insertId]
    );

    res.status(201).json({
      success: true,
      message: 'Stock item added successfully',
      data: { id: result.insertId }
    });

  } catch (error) {
    console.error('Add stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add stock item'
    });
  }
});

// Update stock item
router.put('/:id', [
  authenticateToken,
  requirePermission('stock', 'write'),
  validate
], async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    // Check if stock exists
    const [existing] = await db.query('SELECT * FROM stock WHERE id = ?', [id]);
    
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Stock item not found'
      });
    }

    // Build update query
    const allowedFields = [
      'sn', 'product_description', 'buying_price_usd', 'quantity', 'selling_price_lrd',
      'supplier_id', 'category_id', 'expiry_date', 'batch_number', 'min_stock_level'
    ];

    const updateFields = [];
    const updateValues = [];

    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        updateFields.push(`${field} = ?`);
        updateValues.push(updates[field]);
      }
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    updateValues.push(id);

    await db.query(
      `UPDATE stock SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    // Log action
    await db.query(
      'INSERT INTO audit_log (user_id, action, table_name, record_id, old_values, new_values) VALUES (?, ?, ?, ?, ?, ?)',
      [req.user.userId, 'UPDATE_STOCK', 'stock', id, JSON.stringify(existing[0]), JSON.stringify(updates)]
    );

    res.json({
      success: true,
      message: 'Stock item updated successfully'
    });

  } catch (error) {
    console.error('Update stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update stock item'
    });
  }
});

// Delete stock item (soft delete)
router.delete('/:id', authenticateToken, requirePermission('stock', 'write'), async (req, res) => {
  try {
    const { id } = req.params;

    const [existing] = await db.query('SELECT * FROM stock WHERE id = ?', [id]);
    
    if (existing.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Stock item not found'
      });
    }

    await db.query(
      'UPDATE stock SET is_discontinued = TRUE WHERE id = ?',
      [id]
    );

    // Log action
    await db.query(
      'INSERT INTO audit_log (user_id, action, table_name, record_id) VALUES (?, ?, ?, ?)',
      [req.user.userId, 'DELETE_STOCK', 'stock', id]
    );

    res.json({
      success: true,
      message: 'Stock item deleted successfully'
    });

  } catch (error) {
    console.error('Delete stock error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete stock item'
    });
  }
});

// Bulk import from CSV
router.post('/import', [
  authenticateToken,
  requirePermission('stock', 'write'),
  upload.single('file')
], async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'CSV file is required'
      });
    }

    const results = [];
    const errors = [];

    fs.createReadStream(req.file.path)
      .pipe(csv())
      .on('data', (row) => {
        results.push(row);
      })
      .on('end', async () => {
        let imported = 0;

        for (const row of results) {
          try {
            // Check if SN exists
            const [existing] = await db.query('SELECT id FROM stock WHERE sn = ?', [row.sn]);
            
            if (existing.length > 0) {
              errors.push({ sn: row.sn, error: 'SN already exists' });
              continue;
            }

            await db.query(
              `INSERT INTO stock (
                sn, product_description, buying_price_usd, quantity, selling_price_lrd,
                supplier_id, category_id, expiry_date, batch_number, min_stock_level, created_by
              ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
              [
                row.sn || '',
                row.product_description || '',
                parseFloat(row.buying_price_usd) || 0,
                parseInt(row.quantity) || 0,
                parseFloat(row.selling_price_lrd) || 0,
                row.supplier_id || null,
                row.category_id || null,
                row.expiry_date || null,
                row.batch_number || null,
                parseInt(row.min_stock_level) || 10,
                req.user.userId
              ]
            );

            imported++;
          } catch (error) {
            errors.push({ sn: row.sn, error: error.message });
          }
        }

        // Clean up uploaded file
        fs.unlinkSync(req.file.path);

        res.json({
          success: true,
          message: `Imported ${imported} of ${results.length} items`,
          data: {
            imported,
            total: results.length,
            errors
          }
        });
      })
      .on('error', (error) => {
        fs.unlinkSync(req.file.path);
        res.status(500).json({
          success: false,
          message: 'Failed to parse CSV file'
        });
      });

  } catch (error) {
    console.error('Import error:', error);
    res.status(500).json({
      success: false,
      message: 'Import failed'
    });
  }
});

module.exports = router;
