const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requirePermission } = require('../middleware/role');
const { validate } = require('../middleware/validator');

// Get all suppliers
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { active_only } = req.query;

    let query = 'SELECT * FROM suppliers';
    
    if (active_only === 'true') {
      query += ' WHERE is_active = TRUE';
    }

    query += ' ORDER BY name ASC';

    const [suppliers] = await db.query(query);

    res.json({
      success: true,
      data: suppliers
    });

  } catch (error) {
    console.error('Get suppliers error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve suppliers'
    });
  }
});

// Add new supplier
router.post('/', [
  authenticateToken,
  requirePermission('suppliers', 'write'),
  body('name').notEmpty().withMessage('Supplier name is required'),
  validate
], async (req, res) => {
  try {
    const { name, contact_person, phone, email, address, notes } = req.body;

    const [result] = await db.query(
      'INSERT INTO suppliers (name, contact_person, phone, email, address, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [name, contact_person || null, phone || null, email || null, address || null, notes || null]
    );

    res.status(201).json({
      success: true,
      message: 'Supplier added successfully',
      data: { id: result.insertId }
    });

  } catch (error) {
    console.error('Add supplier error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to add supplier'
    });
  }
});

// Update supplier
router.put('/:id', [
  authenticateToken,
  requirePermission('suppliers', 'write'),
  validate
], async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const allowedFields = ['name', 'contact_person', 'phone', 'email', 'address', 'notes', 'is_active'];
    const updateFields = [];
    const updateValues = [];

    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        updateFields.push(`${field} = ?`);
        updateValues.push(updates[field]);
      }
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields to update'
      });
    }

    updateValues.push(id);

    await db.query(
      `UPDATE suppliers SET ${updateFields.join(', ')} WHERE id = ?`,
      updateValues
    );

    res.json({
      success: true,
      message: 'Supplier updated successfully'
    });

  } catch (error) {
    console.error('Update supplier error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update supplier'
    });
  }
});

module.exports = router;
