const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const db = require('../config/db');
const { authenticateToken } = require('../middleware/auth');
const { requireRole } = require('../middleware/role');
const { validate } = require('../middleware/validator');

// Get all users (Admin only)
router.get('/', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const [users] = await db.query(`
      SELECT id, email, full_name, role, phone, is_active, login_attempts, locked_until, created_at
      FROM users
      ORDER BY created_at DESC
    `);

    res.json({
      success: true,
      data: users
    });

  } catch (error) {
    console.error('Get users error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve users'
    });
  }
});

// Get user permissions
router.get('/:id/permissions', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    const [permissions] = await db.query(`
      SELECT * FROM user_permissions
      WHERE user_id = ?
      ORDER BY module ASC
    `, [req.params.id]);

    res.json({
      success: true,
      data: permissions
    });

  } catch (error) {
    console.error('Get permissions error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to retrieve permissions'
    });
  }
});

// Update user permissions (Admin only)
router.post('/:id/permissions', [
  authenticateToken,
  requireRole('admin'),
  body('module').notEmpty().withMessage('Module is required'),
  body('can_read').isBoolean().withMessage('Read permission must be boolean'),
  body('can_write').isBoolean().withMessage('Write permission must be boolean'),
  validate
], async (req, res) => {
  try {
    const { id } = req.params;
    const { module, can_read, can_write, expires_at } = req.body;

    // Check if user exists and is a worker
    const [users] = await db.query('SELECT role FROM users WHERE id = ?', [id]);
    
    if (users.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    if (users[0].role !== 'worker') {
      return res.status(400).json({
        success: false,
        message: 'Permissions can only be set for worker accounts'
      });
    }

    // Insert or update permission
    await db.query(`
      INSERT INTO user_permissions (user_id, module, can_read, can_write, expires_at)
      VALUES (?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        can_read = VALUES(can_read),
        can_write = VALUES(can_write),
        expires_at = VALUES(expires_at)
    `, [id, module, can_read, can_write, expires_at || null]);

    res.json({
      success: true,
      message: 'Permissions updated successfully'
    });

  } catch (error) {
    console.error('Update permissions error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update permissions'
    });
  }
});

// Delete user permission
router.delete('/:id/permissions/:permissionId', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    await db.query('DELETE FROM user_permissions WHERE id = ?', [req.params.permissionId]);

    res.json({
      success: true,
      message: 'Permission removed successfully'
    });

  } catch (error) {
    console.error('Delete permission error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to remove permission'
    });
  }
});

// Update user status (Admin only)
router.patch('/:id/status', [
  authenticateToken,
  requireRole('admin'),
  body('is_active').isBoolean().withMessage('Status must be boolean'),
  validate
], async (req, res) => {
  try {
    const { id } = req.params;
    const { is_active } = req.body;

    await db.query('UPDATE users SET is_active = ? WHERE id = ?', [is_active, id]);

    res.json({
      success: true,
      message: `User ${is_active ? 'activated' : 'deactivated'} successfully`
    });

  } catch (error) {
    console.error('Update user status error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update user status'
    });
  }
});

// Reset user password (Admin only)
router.post('/:id/reset-password', [
  authenticateToken,
  requireRole('admin'),
  body('newPassword')
    .isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
    .withMessage('Password must contain uppercase, lowercase, number and special character'),
  validate
], async (req, res) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await db.query(
      'UPDATE users SET password = ?, login_attempts = 0, locked_until = NULL WHERE id = ?',
      [hashedPassword, id]
    );

    res.json({
      success: true,
      message: 'Password reset successfully'
    });

  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to reset password'
    });
  }
});

// Unlock user account (Admin only)
router.post('/:id/unlock', authenticateToken, requireRole('admin'), async (req, res) => {
  try {
    await db.query(
      'UPDATE users SET login_attempts = 0, locked_until = NULL WHERE id = ?',
      [req.params.id]
    );

    res.json({
      success: true,
      message: 'User account unlocked successfully'
    });

  } catch (error) {
    console.error('Unlock account error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to unlock account'
    });
  }
});

module.exports = router;
