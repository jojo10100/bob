const nodemailer = require('nodemailer');

// Create transporter
const createTransporter = () => {
  // Check if email is configured
  if (!process.env.EMAIL_HOST || !process.env.EMAIL_USER) {
    console.warn('Email service not configured. Set EMAIL_HOST and EMAIL_USER in .env file.');
    return null;
  }

  return nodemailer.createTransporter({
    host: process.env.EMAIL_HOST,
    port: parseInt(process.env.EMAIL_PORT || '587'),
    secure: process.env.EMAIL_SECURE === 'true', // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASSWORD
    }
  });
};

// Send password reset email
const sendPasswordResetEmail = async (email, resetToken, userName) => {
  const transporter = createTransporter();
  
  if (!transporter) {
    console.log('Email not configured. Password reset token:', resetToken);
    return { success: false, message: 'Email service not configured' };
  }

  const resetLink = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password.html?token=${resetToken}`;

  const mailOptions = {
    from: `"${process.env.EMAIL_FROM_NAME || 'SmartStock Pharmacy'}" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Password Reset Request - SmartStock',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
          .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
          .warning { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🔐 Password Reset Request</h1>
          </div>
          <div class="content">
            <p>Hello ${userName},</p>
            <p>We received a request to reset your password for your SmartStock account.</p>
            <p>Click the button below to reset your password:</p>
            <p style="text-align: center;">
              <a href="${resetLink}" class="button">Reset Password</a>
            </p>
            <p>Or copy and paste this link into your browser:</p>
            <p style="word-break: break-all; background: white; padding: 10px; border-radius: 4px;">
              ${resetLink}
            </p>
            <div class="warning">
              <strong>⚠️ Important:</strong>
              <ul>
                <li>This link will expire in <strong>1 hour</strong></li>
                <li>If you didn't request this, please ignore this email</li>
                <li>Never share this link with anyone</li>
              </ul>
            </div>
          </div>
          <div class="footer">
            <p>This is an automated email from SmartStock Pharmacy Management System</p>
            <p>Please do not reply to this email</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true, message: 'Password reset email sent successfully' };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, message: 'Failed to send email', error: error.message };
  }
};

// Send welcome email for new users
const sendWelcomeEmail = async (email, userName, temporaryPassword = null) => {
  const transporter = createTransporter();
  
  if (!transporter) {
    console.log('Email not configured. Welcome email not sent to:', email);
    return { success: false, message: 'Email service not configured' };
  }

  const loginLink = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/login.html`;

  const mailOptions = {
    from: `"${process.env.EMAIL_FROM_NAME || 'SmartStock Pharmacy'}" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Welcome to SmartStock - Account Created',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
          .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
          .credentials { background: white; padding: 15px; border-radius: 4px; border-left: 4px solid #667eea; margin: 20px 0; }
          .info-box { background: #e3f2fd; border-left: 4px solid #2196f3; padding: 15px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>👋 Welcome to SmartStock!</h1>
          </div>
          <div class="content">
            <p>Hello ${userName},</p>
            <p>Your account has been successfully created in the SmartStock Pharmacy Management System.</p>
            
            ${temporaryPassword ? `
              <div class="credentials">
                <h3>Your Login Credentials:</h3>
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Temporary Password:</strong> ${temporaryPassword}</p>
              </div>
              <div class="info-box">
                <strong>🔒 Security Notice:</strong>
                <p>Please change your password after your first login for security purposes.</p>
              </div>
            ` : `
              <p>Your administrator has created an account for you. Please contact them for your login credentials.</p>
            `}

            <p style="text-align: center;">
              <a href="${loginLink}" class="button">Login to SmartStock</a>
            </p>

            <h3>Getting Started:</h3>
            <ul>
              <li>📊 Access the dashboard for real-time insights</li>
              <li>📦 Manage inventory and stock levels</li>
              <li>💰 Process sales and track transactions</li>
              <li>📈 Generate reports and analytics</li>
            </ul>

            <p>If you have any questions or need assistance, please contact your system administrator.</p>
          </div>
          <div class="footer">
            <p>This is an automated email from SmartStock Pharmacy Management System</p>
            <p>Please do not reply to this email</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true, message: 'Welcome email sent successfully' };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, message: 'Failed to send email', error: error.message };
  }
};

// Send low stock alert email
const sendLowStockAlert = async (email, lowStockItems) => {
  const transporter = createTransporter();
  
  if (!transporter) {
    console.log('Email not configured. Low stock alert not sent');
    return { success: false, message: 'Email service not configured' };
  }

  const itemsList = lowStockItems.map(item => 
    `<tr>
      <td style="padding: 10px; border-bottom: 1px solid #ddd;">${item.product_description}</td>
      <td style="padding: 10px; border-bottom: 1px solid #ddd; text-align: center;">${item.quantity_in_stock}</td>
      <td style="padding: 10px; border-bottom: 1px solid #ddd; text-align: center;">${item.reorder_level}</td>
    </tr>`
  ).join('');

  const mailOptions = {
    from: `"${process.env.EMAIL_FROM_NAME || 'SmartStock Pharmacy'}" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: '⚠️ Low Stock Alert - SmartStock',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { background: #ff9800; color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
          .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 8px 8px; }
          table { width: 100%; background: white; border-collapse: collapse; margin: 20px 0; }
          th { background: #667eea; color: white; padding: 12px; text-align: left; }
          .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>⚠️ Low Stock Alert</h1>
          </div>
          <div class="content">
            <p>The following items are running low in stock and need to be reordered:</p>
            <table>
              <thead>
                <tr>
                  <th>Product</th>
                  <th style="text-align: center;">Current Stock</th>
                  <th style="text-align: center;">Reorder Level</th>
                </tr>
              </thead>
              <tbody>
                ${itemsList}
              </tbody>
            </table>
            <p><strong>Action Required:</strong> Please review and reorder these items to maintain adequate stock levels.</p>
          </div>
          <div class="footer">
            <p>This is an automated alert from SmartStock Pharmacy Management System</p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    await transporter.sendMail(mailOptions);
    return { success: true, message: 'Low stock alert sent successfully' };
  } catch (error) {
    console.error('Email send error:', error);
    return { success: false, message: 'Failed to send email', error: error.message };
  }
};

module.exports = {
  sendPasswordResetEmail,
  sendWelcomeEmail,
  sendLowStockAlert
};
