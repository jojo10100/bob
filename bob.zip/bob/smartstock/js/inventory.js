// Inventory Analysis JavaScript

let categoryValueChart = null;
let movementTrendChart = null;
let profitMarginChart = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Check authentication and permissions
  if (!auth.isAuthenticated()) {
    window.location.href = '/login.html';
    return;
  }

  if (!auth.hasPermission('inventory', 'read')) {
    ui.showAlert('You do not have permission to access this page', 'error');
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 2000);
    return;
  }

  // Initialize page
  initializePage();
  await loadInventoryData();

  // Event listeners
  setupEventListeners();
});

function initializePage() {
  const user = auth.getUser();
  
  if (!user) {
    auth.logout();
    return;
  }

  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userRole').textContent = user.role;

  if (user.role === 'admin') {
    document.body.classList.add('is-admin');
  }
}

function setupEventListeners() {
  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      auth.logout();
    }
  });

  // Refresh button
  document.getElementById('refreshBtn').addEventListener('click', () => {
    loadInventoryData();
  });

  // Export report button
  document.getElementById('exportReportBtn').addEventListener('click', () => {
    exportInventoryReport();
  });

  // Tab navigation
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tabName = e.currentTarget.dataset.tab;
      switchTab(tabName);
    });
  });
}

function switchTab(tabName) {
  // Update tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  // Update tab content
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
  });
  document.getElementById(tabName).classList.add('active');
}

async function loadInventoryData() {
  try {
    ui.showAlert('Loading inventory data...', 'info');

    // Load data in parallel
    const [stock, sales, alerts] = await Promise.all([
      loadStockData(),
      loadSalesData(),
      loadAlerts()
    ]);

    // Analyze data
    const analysis = analyzeInventory(stock, sales);

    // Update UI
    updateSummaryCards(analysis);
    updateOverviewCharts(stock, sales);
    updateFastMovingTable(analysis.fastMoving);
    updateSlowMovingTable(analysis.slowMoving);
    updateNoSaleTable(analysis.noSale);
    updateExpiringTable(alerts.expiringSoon);
    updateReorderTable(analysis.reorder);

    ui.showAlert('Inventory data loaded successfully', 'success');

  } catch (error) {
    console.error('Load inventory error:', error);
    ui.showAlert('Failed to load inventory data', 'error');
  }
}

async function loadStockData() {
  try {
    const response = await api.get('/stock?limit=1000');
    return response.data.stock || [];
  } catch (error) {
    console.error('Load stock error:', error);
    return [];
  }
}

async function loadSalesData() {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const startDate = thirtyDaysAgo.toISOString().split('T')[0];

    const response = await api.get(`/sales/reports/top-products?limit=100&startDate=${startDate}`);
    return response.data || [];
  } catch (error) {
    console.error('Load sales error:', error);
    return [];
  }
}

async function loadAlerts() {
  try {
    const response = await api.get('/dashboard/alerts');
    return response.data || {};
  } catch (error) {
    console.error('Load alerts error:', error);
    return {};
  }
}

function analyzeInventory(stock, sales) {
  // Calculate total value
  const totalValue = stock.reduce((sum, item) => {
    return sum + (item.quantity * item.buying_price_usd);
  }, 0);

  // Categorize by sales performance
  const salesMap = new Map();
  sales.forEach(sale => {
    salesMap.set(sale.product_sn, {
      totalSold: sale.total_quantity_sold,
      revenue: sale.total_revenue,
      profit: sale.total_profit
    });
  });

  // Add sales data to stock items
  const enrichedStock = stock.map(item => ({
    ...item,
    salesData: salesMap.get(item.sn) || { totalSold: 0, revenue: 0, profit: 0 }
  }));

  // Sort by sales performance
  const sortedByPerformance = [...enrichedStock].sort((a, b) => {
    return b.salesData.totalSold - a.salesData.totalSold;
  });

  // Fast moving (top 25%)
  const fastMovingCount = Math.ceil(sortedByPerformance.length * 0.25);
  const fastMoving = sortedByPerformance.slice(0, fastMovingCount);

  // Slow moving (bottom 25% with sales)
  const withSales = sortedByPerformance.filter(item => item.salesData.totalSold > 0);
  const slowMovingCount = Math.ceil(withSales.length * 0.25);
  const slowMoving = withSales.slice(-slowMovingCount);

  // No sale items (no sales in last 30 days)
  const noSale = enrichedStock.filter(item => item.salesData.totalSold === 0);

  // Reorder recommendations (low stock items)
  const reorder = enrichedStock
    .filter(item => item.quantity <= item.min_stock_level && !item.is_discontinued)
    .sort((a, b) => {
      const aPriority = a.quantity === 0 ? 3 : (a.quantity <= a.min_stock_level * 0.5 ? 2 : 1);
      const bPriority = b.quantity === 0 ? 3 : (b.quantity <= b.min_stock_level * 0.5 ? 2 : 1);
      return bPriority - aPriority;
    });

  return {
    totalItems: stock.length,
    totalValue,
    fastMoving,
    slowMoving,
    noSale,
    reorder
  };
}

function updateSummaryCards(analysis) {
  document.getElementById('totalItems').textContent = analysis.totalItems;
  document.getElementById('totalValue').textContent = ui.formatUSD(analysis.totalValue);
  document.getElementById('fastMovingCount').textContent = analysis.fastMoving.length;
  document.getElementById('slowMovingCount').textContent = analysis.slowMoving.length;
}

function updateOverviewCharts(stock, sales) {
  // Category value chart
  const categoryData = {};
  stock.forEach(item => {
    const category = item.category_name || 'Uncategorized';
    if (!categoryData[category]) {
      categoryData[category] = 0;
    }
    categoryData[category] += item.quantity * item.buying_price_usd;
  });

  const ctx1 = document.getElementById('categoryValueChart');
  if (categoryValueChart) categoryValueChart.destroy();

  const colors = generateColors(Object.keys(categoryData).length);

  categoryValueChart = new Chart(ctx1, {
    type: 'pie',
    data: {
      labels: Object.keys(categoryData),
      datasets: [{
        data: Object.values(categoryData),
        backgroundColor: colors,
        borderWidth: 2,
        borderColor: '#fff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const label = context.label || '';
              const value = ui.formatUSD(context.parsed);
              const total = context.dataset.data.reduce((a, b) => a + b, 0);
              const percentage = ((context.parsed / total) * 100).toFixed(1);
              return `${label}: ${value} (${percentage}%)`;
            }
          }
        }
      }
    }
  });

  // Movement trend (simulated - in real app, would use historical data)
  const ctx2 = document.getElementById('movementTrendChart');
  if (movementTrendChart) movementTrendChart.destroy();

  const last7Days = Array.from({length: 7}, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });

  movementTrendChart = new Chart(ctx2, {
    type: 'line',
    data: {
      labels: last7Days,
      datasets: [{
        label: 'Stock Movement',
        data: [85, 92, 78, 95, 88, 91, 87],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Items Moved'
          }
        }
      }
    }
  });

  // Profit margin by category
  const categoryMargins = {};
  stock.forEach(item => {
    const category = item.category_name || 'Uncategorized';
    if (!categoryMargins[category]) {
      categoryMargins[category] = { totalCost: 0, totalRevenue: 0 };
    }
    const costInLRD = item.buying_price_usd * 150; // Assuming 150 LRD = 1 USD
    const margin = ((item.selling_price_lrd - costInLRD) / item.selling_price_lrd) * 100;
    categoryMargins[category].totalCost += costInLRD * item.quantity;
    categoryMargins[category].totalRevenue += item.selling_price_lrd * item.quantity;
  });

  const margins = Object.entries(categoryMargins).map(([category, data]) => {
    const margin = ((data.totalRevenue - data.totalCost) / data.totalRevenue) * 100;
    return { category, margin };
  });

  const ctx3 = document.getElementById('profitMarginChart');
  if (profitMarginChart) profitMarginChart.destroy();

  profitMarginChart = new Chart(ctx3, {
    type: 'bar',
    data: {
      labels: margins.map(m => m.category),
      datasets: [{
        label: 'Profit Margin (%)',
        data: margins.map(m => m.margin.toFixed(1)),
        backgroundColor: 'rgba(40, 167, 69, 0.8)',
        borderColor: 'rgba(40, 167, 69, 1)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Margin (%)'
          },
          ticks: {
            callback: function(value) {
              return value + '%';
            }
          }
        }
      }
    }
  });
}

function updateFastMovingTable(items) {
  const tbody = document.getElementById('fastMovingTable');

  if (items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No data available</td></tr>';
    return;
  }

  tbody.innerHTML = items.slice(0, 20).map((item, index) => {
    const rank = index + 1;
    const rankClass = rank === 1 ? 'rank-1' : rank === 2 ? 'rank-2' : rank === 3 ? 'rank-3' : 'rank-other';
    const stockStatus = getInventoryStockStatus(item);

    return `
      <tr>
        <td>
          <span class="rank-badge ${rankClass}">${rank}</span>
        </td>
        <td>
          <strong>${escapeHtml(item.product_description)}</strong><br>
          <small class="text-muted">SN: ${escapeHtml(item.sn)}</small>
        </td>
        <td>${item.category_name || 'N/A'}</td>
        <td><strong>${item.salesData.totalSold}</strong></td>
        <td>${ui.formatLRD(item.salesData.revenue)}</td>
        <td>${item.quantity}</td>
        <td>
          <span class="status-indicator ${stockStatus.class}">
            ${stockStatus.icon} ${stockStatus.text}
          </span>
        </td>
      </tr>
    `;
  }).join('');
}

function updateSlowMovingTable(items) {
  const tbody = document.getElementById('slowMovingTable');

  if (items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No slow-moving items</td></tr>';
    return;
  }

  tbody.innerHTML = items.map(item => `
    <tr class="warning">
      <td>
        <strong>${escapeHtml(item.product_description)}</strong><br>
        <small class="text-muted">SN: ${escapeHtml(item.sn)}</small>
      </td>
      <td>${item.category_name || 'N/A'}</td>
      <td>${item.quantity}</td>
      <td>Last 30 days</td>
      <td><span class="days-counter days-warning">30</span></td>
      <td>
        <button class="btn btn-sm btn-warning" onclick="considerDiscount('${item.id}')">
          <i class="fas fa-tag"></i> Consider Discount
        </button>
      </td>
    </tr>
  `).join('');
}

function updateNoSaleTable(items) {
  const tbody = document.getElementById('noSaleTable');

  if (items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">All items have sales!</td></tr>';
    return;
  }

  tbody.innerHTML = items.map(item => {
    const value = item.quantity * item.buying_price_usd;
    const daysOld = Math.floor((new Date() - new Date(item.created_at)) / (1000 * 60 * 60 * 24));

    return `
      <tr class="critical">
        <td>
          <strong>${escapeHtml(item.product_description)}</strong><br>
          <small class="text-muted">SN: ${escapeHtml(item.sn)}</small>
        </td>
        <td>${item.category_name || 'N/A'}</td>
        <td>${item.quantity}</td>
        <td>${ui.formatUSD(value)}</td>
        <td><span class="days-counter days-critical">${daysOld}</span></td>
        <td>
          <span class="recommendation">
            <i class="fas fa-lightbulb"></i> Review pricing or discontinue
          </span>
        </td>
      </tr>
    `;
  }).join('');
}

function updateExpiringTable(items) {
  const tbody = document.getElementById('expiringTable');

  if (!items || items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No expiring items</td></tr>';
    return;
  }

  tbody.innerHTML = items.map(item => {
    const today = new Date();
    const expiryDate = new Date(item.expiry_date);
    const daysRemaining = Math.floor((expiryDate - today) / (1000 * 60 * 60 * 24));
    const daysClass = daysRemaining < 7 ? 'days-critical' : daysRemaining < 15 ? 'days-warning' : 'days-ok';

    return `
      <tr class="${daysRemaining < 7 ? 'critical' : 'warning'}">
        <td>
          <strong>${escapeHtml(item.product_description)}</strong><br>
          <small class="text-muted">SN: ${escapeHtml(item.sn)}</small>
        </td>
        <td>${item.batch_number || 'N/A'}</td>
        <td>${item.quantity}</td>
        <td>${ui.formatDate(item.expiry_date)}</td>
        <td>
          <span class="days-counter ${daysClass}">${daysRemaining} days</span>
        </td>
        <td>
          <button class="btn btn-sm btn-danger" onclick="markForDisposal('${item.id}')">
            <i class="fas fa-exclamation-triangle"></i> Priority Sale
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function updateReorderTable(items) {
  const tbody = document.getElementById('reorderTable');

  if (items.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="text-center text-muted">No reorder needed</td></tr>';
    return;
  }

  tbody.innerHTML = items.map(item => {
    const priority = item.quantity === 0 ? 'high' : 
                     item.quantity <= item.min_stock_level * 0.5 ? 'medium' : 'low';
    const priorityText = priority === 'high' ? 'URGENT' : 
                         priority === 'medium' ? 'HIGH' : 'NORMAL';
    const suggestedOrder = Math.max(item.min_stock_level * 2 - item.quantity, item.min_stock_level);

    return `
      <tr>
        <td>
          <span class="priority-badge priority-${priority}">
            <i class="fas fa-exclamation-circle"></i> ${priorityText}
          </span>
        </td>
        <td>
          <strong>${escapeHtml(item.product_description)}</strong><br>
          <small class="text-muted">SN: ${escapeHtml(item.sn)}</small>
        </td>
        <td><strong>${item.quantity}</strong></td>
        <td>${item.min_stock_level}</td>
        <td><strong class="text-success">${suggestedOrder}</strong></td>
        <td>${item.supplier_name || 'N/A'}</td>
        <td>
          <button class="btn btn-sm btn-primary" onclick="createPurchaseOrder('${item.id}', ${suggestedOrder})">
            <i class="fas fa-shopping-cart"></i> Order
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

function getInventoryStockStatus(item) {
  if (item.quantity === 0) {
    return { class: 'status-critical', icon: '<i class="fas fa-times-circle"></i>', text: 'Out of Stock' };
  } else if (item.quantity <= item.min_stock_level) {
    return { class: 'status-warning', icon: '<i class="fas fa-exclamation-triangle"></i>', text: 'Low Stock' };
  } else {
    return { class: 'status-good', icon: '<i class="fas fa-check-circle"></i>', text: 'In Stock' };
  }
}

function generateColors(count) {
  const colors = [
    'rgba(255, 99, 132, 0.8)',
    'rgba(54, 162, 235, 0.8)',
    'rgba(255, 206, 86, 0.8)',
    'rgba(75, 192, 192, 0.8)',
    'rgba(153, 102, 255, 0.8)',
    'rgba(255, 159, 64, 0.8)',
    'rgba(199, 199, 199, 0.8)',
    'rgba(83, 102, 255, 0.8)',
    'rgba(255, 99, 255, 0.8)',
    'rgba(99, 255, 132, 0.8)'
  ];
  
  return colors.slice(0, count);
}

function exportInventoryReport() {
  ui.showAlert('Exporting inventory report...', 'info');
  
  // In a real implementation, this would generate a comprehensive PDF or Excel report
  ui.showAlert('Export feature coming soon', 'warning');
}

// Global functions for button actions
window.considerDiscount = function(itemId) {
  ui.showAlert('Discount feature coming soon', 'info');
};

window.markForDisposal = function(itemId) {
  ui.showAlert('Priority sale feature coming soon', 'info');
};

window.createPurchaseOrder = function(itemId, quantity) {
  ui.showAlert(`Creating purchase order for ${quantity} units...`, 'info');
};

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text).replace(/[&<>"']/g, m => map[m]);
}
