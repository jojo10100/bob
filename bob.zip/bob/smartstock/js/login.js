// Login Page JavaScript

document.addEventListener('DOMContentLoaded', () => {
  // Check if already logged in
  if (auth.isAuthenticated()) {
    window.location.href = '/index.html';
    return;
  }

  // DOM Elements
  const loginForm = document.getElementById('loginForm');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const togglePasswordBtn = document.getElementById('togglePassword');
  const rememberMeCheckbox = document.getElementById('rememberMe');
  const loginBtn = document.getElementById('loginBtn');
  const loginMessage = document.getElementById('loginMessage');
  const forgotPasswordLink = document.getElementById('forgotPasswordLink');
  const forgotPasswordModal = document.getElementById('forgotPasswordModal');
  const closeForgotModal = document.getElementById('closeForgotModal');
  const forgotPasswordForm = document.getElementById('forgotPasswordForm');
  const resetMessage = document.getElementById('resetMessage');
  const languageSelect = document.getElementById('languageSelect');
  const darkModeToggle = document.getElementById('darkModeToggle');

  // Load saved email if "Remember Me" was checked
  const savedEmail = localStorage.getItem('rememberedEmail');
  if (savedEmail) {
    emailInput.value = savedEmail;
    rememberMeCheckbox.checked = true;
  }

  // Load saved language
  languageSelect.value = i18n.currentLang;

  // Toggle password visibility
  togglePasswordBtn.addEventListener('click', () => {
    const type = passwordInput.type === 'password' ? 'text' : 'password';
    passwordInput.type = type;
    
    const icon = togglePasswordBtn.querySelector('i');
    icon.classList.toggle('fa-eye');
    icon.classList.toggle('fa-eye-slash');
  });

  // Login form submission
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = emailInput.value.trim();
    const password = passwordInput.value;

    // Clear previous errors
    document.getElementById('emailError').textContent = '';
    document.getElementById('passwordError').textContent = '';
    loginMessage.classList.remove('show', 'success', 'error');

    // Validate
    if (!ui.isValidEmail(email)) {
      document.getElementById('emailError').textContent = 'Please enter a valid email address';
      return;
    }

    if (!password) {
      document.getElementById('passwordError').textContent = 'Password is required';
      return;
    }

    // Show loading state
    loginBtn.classList.add('loading');
    loginBtn.disabled = true;

    try {
      const response = await auth.login(email, password);

      // Handle "Remember Me"
      if (rememberMeCheckbox.checked) {
        localStorage.setItem('rememberedEmail', email);
      } else {
        localStorage.removeItem('rememberedEmail');
      }

      // Show success message
      showMessage('Login successful! Redirecting...', 'success');

      // Redirect to dashboard after short delay
      setTimeout(() => {
        window.location.href = '/index.html';
      }, 1000);

    } catch (error) {
      // Show error message
      showMessage(error.message || 'Login failed. Please try again.', 'error');
      
      // Reset button state
      loginBtn.classList.remove('loading');
      loginBtn.disabled = false;
    }
  });

  // Forgot password link
  forgotPasswordLink.addEventListener('click', (e) => {
    e.preventDefault();
    forgotPasswordModal.classList.add('show');
  });

  // Close forgot password modal
  closeForgotModal.addEventListener('click', () => {
    forgotPasswordModal.classList.remove('show');
    forgotPasswordForm.reset();
    resetMessage.classList.remove('show', 'success', 'error');
  });

  // Close modal on outside click
  forgotPasswordModal.addEventListener('click', (e) => {
    if (e.target === forgotPasswordModal) {
      forgotPasswordModal.classList.remove('show');
    }
  });

  // Forgot password form submission
  forgotPasswordForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const resetEmail = document.getElementById('resetEmail').value.trim();

    if (!ui.isValidEmail(resetEmail)) {
      showResetMessage('Please enter a valid email address', 'error');
      return;
    }

    try {
      const response = await api.post('/auth/forgot-password', { email: resetEmail });
      
      if (response.success) {
        showResetMessage('Password reset link sent to your email', 'success');
        
        setTimeout(() => {
          forgotPasswordModal.classList.remove('show');
          forgotPasswordForm.reset();
          resetMessage.classList.remove('show');
        }, 3000);
      }
    } catch (error) {
      showResetMessage(error.message || 'Failed to send reset link', 'error');
    }
  });

  // Language selection
  languageSelect.addEventListener('change', (e) => {
    i18n.setLanguage(e.target.value);
  });

  // Dark mode toggle
  darkModeToggle.addEventListener('click', () => {
    darkMode.toggle();
  });

  // Helper function to show login message
  function showMessage(message, type) {
    loginMessage.textContent = message;
    loginMessage.classList.add('show', type);
    
    setTimeout(() => {
      loginMessage.classList.remove('show');
    }, 5000);
  }

  // Helper function to show reset message
  function showResetMessage(message, type) {
    resetMessage.textContent = message;
    resetMessage.classList.add('show', type);
    
    setTimeout(() => {
      resetMessage.classList.remove('show');
    }, 5000);
  }

  // Enter key on email field moves to password
  emailInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      passwordInput.focus();
    }
  });
});
