// Reports JavaScript

let reportChart = null;

document.addEventListener('DOMContentLoaded', async () => {
  // Check authentication and permissions
  if (!auth.isAuthenticated()) {
    window.location.href = '/login.html';
    return;
  }

  if (!auth.hasPermission('reports', 'read')) {
    ui.showAlert('You do not have permission to access this page', 'error');
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 2000);
    return;
  }

  // Initialize page
  initializePage();
  setupEventListeners();
});

function initializePage() {
  const user = auth.getUser();
  
  if (!user) {
    auth.logout();
    return;
  }

  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userRole').textContent = user.role;

  if (user.role === 'admin') {
    document.body.classList.add('is-admin');
  }
}

function setupEventListeners() {
  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      auth.logout();
    }
  });

  // Refresh button
  document.getElementById('refreshBtn').addEventListener('click', () => {
    const reportType = document.getElementById('reportType').value;
    if (document.getElementById('reportResults').style.display !== 'none') {
      generateReport();
    }
  });

  // Report type cards
  document.querySelectorAll('.report-card').forEach(card => {
    card.addEventListener('click', () => {
      const reportType = card.dataset.report;
      document.querySelectorAll('.report-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      
      const reportSelect = document.getElementById('reportType');
      if (reportType === 'sales') reportSelect.value = 'sales';
      else if (reportType === 'inventory') reportSelect.value = 'inventory';
      else if (reportType === 'profit') reportSelect.value = 'profit';
      else if (reportType === 'custom') reportSelect.value = 'top-products';
    });
  });

  // Date range selector
  document.getElementById('dateRange').addEventListener('change', (e) => {
    const customDateGroup = document.getElementById('customDateGroup');
    if (e.target.value === 'custom') {
      customDateGroup.style.display = 'flex';
    } else {
      customDateGroup.style.display = 'none';
    }
  });

  // Generate report button
  document.getElementById('generateReport').addEventListener('click', generateReport);

  // Export report button
  document.getElementById('exportReport').addEventListener('click', exportReport);
}

async function generateReport() {
  try {
    const reportType = document.getElementById('reportType').value;
    const dateRange = document.getElementById('dateRange').value;
    const groupBy = document.getElementById('groupBy').value;

    ui.showAlert('Generating report...', 'info');

    // Show loading state
    const reportResults = document.getElementById('reportResults');
    reportResults.style.display = 'block';
    document.getElementById('reportTableBody').innerHTML = '<tr><td colspan="10" class="report-loading"><i class="fas fa-spinner fa-spin"></i><br>Loading...</td></tr>';

    // Get date range
    const { startDate, endDate } = getDateRange(dateRange);

    let data;
    switch (reportType) {
      case 'sales':
        data = await generateSalesReport(startDate, endDate, groupBy);
        break;
      case 'inventory':
        data = await generateInventoryReport();
        break;
      case 'profit':
        data = await generateProfitReport(startDate, endDate);
        break;
      case 'top-products':
        data = await generateTopProductsReport(startDate, endDate);
        break;
      case 'category':
        data = await generateCategoryReport(startDate, endDate);
        break;
      default:
        data = await generateSalesReport(startDate, endDate, groupBy);
    }

    renderReport(data, reportType);
    generateInsights(data, reportType);

    ui.showAlert('Report generated successfully', 'success');

  } catch (error) {
    console.error('Generate report error:', error);
    ui.showAlert('Failed to generate report', 'error');
  }
}

function getDateRange(range) {
  const endDate = new Date();
  let startDate = new Date();

  switch (range) {
    case 'today':
      startDate = new Date();
      break;
    case 'yesterday':
      startDate.setDate(startDate.getDate() - 1);
      endDate.setDate(endDate.getDate() - 1);
      break;
    case '7days':
      startDate.setDate(startDate.getDate() - 7);
      break;
    case '30days':
      startDate.setDate(startDate.getDate() - 30);
      break;
    case 'thismonth':
      startDate.setDate(1);
      break;
    case 'lastmonth':
      startDate.setMonth(startDate.getMonth() - 1);
      startDate.setDate(1);
      endDate.setDate(0); // Last day of previous month
      break;
    case 'custom':
      startDate = new Date(document.getElementById('customStartDate').value);
      endDate = new Date(document.getElementById('customEndDate').value);
      break;
  }

  return {
    startDate: startDate.toISOString().split('T')[0],
    endDate: endDate.toISOString().split('T')[0]
  };
}

async function generateSalesReport(startDate, endDate, groupBy) {
  const response = await api.get(`/sales/reports/summary?startDate=${startDate}&endDate=${endDate}&groupBy=${groupBy}`);
  return {
    type: 'sales',
    data: response.data || [],
    summary: calculateSalesSummary(response.data || [])
  };
}

async function generateInventoryReport() {
  const response = await api.get('/stock?limit=1000');
  const stock = response.data.stock || [];
  
  return {
    type: 'inventory',
    data: stock,
    summary: calculateInventorySummary(stock)
  };
}

async function generateProfitReport(startDate, endDate) {
  const response = await api.get(`/sales/reports/summary?startDate=${startDate}&endDate=${endDate}&groupBy=day`);
  return {
    type: 'profit',
    data: response.data || [],
    summary: calculateProfitSummary(response.data || [])
  };
}

async function generateTopProductsReport(startDate, endDate) {
  const response = await api.get(`/sales/reports/top-products?limit=20&startDate=${startDate}&endDate=${endDate}`);
  return {
    type: 'top-products',
    data: response.data || [],
    summary: calculateTopProductsSummary(response.data || [])
  };
}

async function generateCategoryReport(startDate, endDate) {
  const response = await api.get('/dashboard/category-distribution');
  return {
    type: 'category',
    data: response.data || [],
    summary: calculateCategorySummary(response.data || [])
  };
}

function calculateSalesSummary(data) {
  const totalSales = data.reduce((sum, item) => sum + (item.total_sales || 0), 0);
  const totalRevenue = data.reduce((sum, item) => sum + parseFloat(item.total_revenue_lrd || 0), 0);
  const totalProfit = data.reduce((sum, item) => sum + parseFloat(item.total_profit || 0), 0);
  const avgProfit = totalSales > 0 ? totalProfit / totalSales : 0;

  return {
    totalSales,
    totalRevenue,
    totalProfit,
    avgProfit
  };
}

function calculateInventorySummary(stock) {
  const totalItems = stock.length;
  const totalValue = stock.reduce((sum, item) => sum + (item.quantity * item.buying_price_usd), 0);
  const totalQuantity = stock.reduce((sum, item) => sum + item.quantity, 0);
  const lowStock = stock.filter(item => item.quantity <= item.min_stock_level).length;

  return {
    totalItems,
    totalValue,
    totalQuantity,
    lowStock
  };
}

function calculateProfitSummary(data) {
  const totalProfit = data.reduce((sum, item) => sum + parseFloat(item.total_profit || 0), 0);
  const totalRevenue = data.reduce((sum, item) => sum + parseFloat(item.total_revenue_lrd || 0), 0);
  const profitMargin = totalRevenue > 0 ? (totalProfit / totalRevenue * 100) : 0;

  return {
    totalProfit,
    totalRevenue,
    profitMargin
  };
}

function calculateTopProductsSummary(data) {
  const totalSold = data.reduce((sum, item) => sum + parseInt(item.total_sold || 0), 0);
  const totalRevenue = data.reduce((sum, item) => sum + parseFloat(item.total_revenue || 0), 0);
  const totalProfit = data.reduce((sum, item) => sum + parseFloat(item.total_profit || 0), 0);

  return {
    products: data.length,
    totalSold,
    totalRevenue,
    totalProfit
  };
}

function calculateCategorySummary(data) {
  const categories = data.length;
  const totalProducts = data.reduce((sum, item) => sum + parseInt(item.product_count || 0), 0);
  const totalValue = data.reduce((sum, item) => sum + parseFloat(item.total_value_usd || 0), 0);

  return {
    categories,
    totalProducts,
    totalValue
  };
}

function renderReport(reportData, reportType) {
  document.getElementById('reportTitle').textContent = getReportTitle(reportType);
  
  // Render summary
  renderSummary(reportData.summary, reportType);
  
  // Render chart
  renderChart(reportData.data, reportType);
  
  // Render table
  renderTable(reportData.data, reportType);
}

function getReportTitle(type) {
  const titles = {
    sales: 'Sales Report',
    inventory: 'Inventory Report',
    profit: 'Profit Analysis',
    'top-products': 'Top Products Report',
    category: 'Category Performance'
  };
  return titles[type] || 'Report Results';
}

function renderSummary(summary, reportType) {
  const container = document.getElementById('reportSummary');
  
  let html = '';
  
  if (reportType === 'sales') {
    html = `
      <div class="summary-metric">
        <div class="metric-label">Total Sales</div>
        <div class="metric-value">${summary.totalSales}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Total Revenue</div>
        <div class="metric-value">${ui.formatLRD(summary.totalRevenue)}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Total Profit</div>
        <div class="metric-value">${ui.formatLRD(summary.totalProfit)}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Avg Profit/Sale</div>
        <div class="metric-value">${ui.formatLRD(summary.avgProfit)}</div>
      </div>
    `;
  } else if (reportType === 'inventory') {
    html = `
      <div class="summary-metric">
        <div class="metric-label">Total Items</div>
        <div class="metric-value">${summary.totalItems}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Total Value</div>
        <div class="metric-value">${ui.formatUSD(summary.totalValue)}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Total Quantity</div>
        <div class="metric-value">${summary.totalQuantity}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Low Stock Items</div>
        <div class="metric-value">${summary.lowStock}</div>
      </div>
    `;
  } else if (reportType === 'profit') {
    html = `
      <div class="summary-metric">
        <div class="metric-label">Total Profit</div>
        <div class="metric-value">${ui.formatLRD(summary.totalProfit)}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Total Revenue</div>
        <div class="metric-value">${ui.formatLRD(summary.totalRevenue)}</div>
      </div>
      <div class="summary-metric">
        <div class="metric-label">Profit Margin</div>
        <div class="metric-value">${summary.profitMargin.toFixed(1)}%</div>
      </div>
    `;
  }
  
  container.innerHTML = html;
}

function renderChart(data, reportType) {
  const ctx = document.getElementById('reportChart');
  
  if (reportChart) {
    reportChart.destroy();
  }

  if (reportType === 'sales' || reportType === 'profit') {
    const labels = data.map(item => item.period || '');
    const revenue = data.map(item => parseFloat(item.total_revenue_lrd || 0));
    const profit = data.map(item => parseFloat(item.total_profit || 0));

    reportChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label: 'Revenue (LRD)',
            data: revenue,
            borderColor: 'rgb(75, 192, 192)',
            backgroundColor: 'rgba(75, 192, 192, 0.2)',
            tension: 0.4,
            fill: true
          },
          {
            label: 'Profit (LRD)',
            data: profit,
            borderColor: 'rgb(40, 167, 69)',
            backgroundColor: 'rgba(40, 167, 69, 0.2)',
            tension: 0.4,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true
          }
        }
      }
    });
  } else if (reportType === 'category') {
    const labels = data.map(item => item.category || 'Uncategorized');
    const values = data.map(item => parseInt(item.product_count || 0));

    reportChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [{
          label: 'Products',
          data: values,
          backgroundColor: 'rgba(54, 162, 235, 0.8)'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: true
      }
    });
  }
}

function renderTable(data, reportType) {
  const thead = document.getElementById('reportTableHead');
  const tbody = document.getElementById('reportTableBody');

  if (reportType === 'sales') {
    thead.innerHTML = `
      <tr>
        <th>Period</th>
        <th>Sales Count</th>
        <th>Revenue (LRD)</th>
        <th>Profit (LRD)</th>
        <th>Avg Profit</th>
      </tr>
    `;
    tbody.innerHTML = data.map(item => `
      <tr>
        <td>${item.period}</td>
        <td>${item.total_sales}</td>
        <td>${ui.formatLRD(item.total_revenue_lrd)}</td>
        <td>${ui.formatLRD(item.total_profit)}</td>
        <td>${ui.formatLRD(item.avg_profit)}</td>
      </tr>
    `).join('');
  } else if (reportType === 'inventory') {
    thead.innerHTML = `
      <tr>
        <th>SN</th>
        <th>Product</th>
        <th>Category</th>
        <th>Quantity</th>
        <th>Value (USD)</th>
      </tr>
    `;
    tbody.innerHTML = data.map(item => `
      <tr>
        <td>${item.sn}</td>
        <td>${escapeHtml(item.product_description)}</td>
        <td>${item.category_name || 'N/A'}</td>
        <td>${item.quantity}</td>
        <td>${ui.formatUSD(item.quantity * item.buying_price_usd)}</td>
      </tr>
    `).join('');
  } else if (reportType === 'top-products') {
    thead.innerHTML = `
      <tr>
        <th>Rank</th>
        <th>Product</th>
        <th>Sold</th>
        <th>Revenue</th>
        <th>Profit</th>
      </tr>
    `;
    tbody.innerHTML = data.map((item, index) => `
      <tr>
        <td>${index + 1}</td>
        <td>${escapeHtml(item.product_description)}</td>
        <td>${item.total_sold}</td>
        <td>${ui.formatLRD(item.total_revenue)}</td>
        <td>${ui.formatLRD(item.total_profit)}</td>
      </tr>
    `).join('');
  }
}

function generateInsights(reportData, reportType) {
  const insightsList = document.getElementById('insightsList');
  const recommendationsList = document.getElementById('recommendationsList');

  // Generate insights based on report type
  let insights = [];
  let recommendations = [];

  if (reportType === 'sales') {
    const summary = reportData.summary;
    const margin = summary.totalRevenue > 0 ? (summary.totalProfit / summary.totalRevenue * 100) : 0;

    insights.push(`<div class="insight-item success">
      <i class="fas fa-check-circle text-success"></i>
      <span>Total profit margin is ${margin.toFixed(1)}%</span>
    </div>`);

    if (summary.totalSales > 0) {
      insights.push(`<div class="insight-item">
        <i class="fas fa-info-circle text-info"></i>
        <span>Average profit per sale: ${ui.formatLRD(summary.avgProfit)}</span>
      </div>`);
    }

    if (margin < 30) {
      recommendations.push(`<div class="recommendation-item">
        <i class="fas fa-lightbulb text-warning"></i>
        <span>Consider reviewing pricing strategy to improve profit margins</span>
      </div>`);
    }
  }

  insightsList.innerHTML = insights.length > 0 ? insights.join('') : '<div class="insight-item"><i class="fas fa-info-circle text-info"></i><span>No insights available</span></div>';
  recommendationsList.innerHTML = recommendations.length > 0 ? recommendations.join('') : '<div class="recommendation-item"><i class="fas fa-lightbulb text-info"></i><span>No recommendations at this time</span></div>';
}

function exportReport() {
  ui.showAlert('Exporting report...', 'info');
  
  // In a real implementation, this would export to PDF or Excel
  ui.showAlert('Export feature coming soon', 'warning');
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text).replace(/[&<>"']/g, m => map[m]);
}
