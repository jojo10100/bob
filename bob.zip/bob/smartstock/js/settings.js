// Settings JavaScript

let users = [];
let categories = [];
let suppliers = [];

document.addEventListener('DOMContentLoaded', async () => {
  // Check authentication and admin role
  if (!auth.isAuthenticated()) {
    window.location.href = '/login.html';
    return;
  }

  if (!auth.isAdmin()) {
    ui.showAlert('Access denied. Admin privileges required.', 'error');
    setTimeout(() => {
      window.location.href = '/index.html';
    }, 2000);
    return;
  }

  // Initialize page
  initializePage();
  await loadAllData();
  setupEventListeners();
});

function initializePage() {
  const user = auth.getUser();
  
  if (!user) {
    auth.logout();
    return;
  }

  document.getElementById('userName').textContent = user.fullName;
  document.getElementById('userRole').textContent = user.role;
  document.body.classList.add('is-admin');

  // Load theme preference
  const isDark = localStorage.getItem('darkMode') === 'true';
  document.getElementById('themeSelect').value = isDark ? 'dark' : 'light';

  // Load language preference
  document.getElementById('languageSelect').value = i18n.currentLang;
}

function setupEventListeners() {
  // Logout
  document.getElementById('logoutBtn').addEventListener('click', () => {
    if (confirm('Are you sure you want to logout?')) {
      auth.logout();
    }
  });

  // Refresh
  document.getElementById('refreshBtn').addEventListener('click', loadAllData);

  // Tab navigation
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tabName = e.currentTarget.dataset.tab;
      switchTab(tabName);
    });
  });

  // Users
  document.getElementById('addUserBtn').addEventListener('click', openUserModal);
  document.getElementById('closeUserModal').addEventListener('click', closeUserModal);
  document.getElementById('cancelUserBtn').addEventListener('click', closeUserModal);
  document.getElementById('userForm').addEventListener('submit', handleUserSubmit);

  // Categories
  document.getElementById('addCategoryBtn').addEventListener('click', openCategoryModal);
  document.getElementById('closeCategoryModal').addEventListener('click', closeCategoryModal);
  document.getElementById('cancelCategoryBtn').addEventListener('click', closeCategoryModal);
  document.getElementById('categoryForm').addEventListener('submit', handleCategorySubmit);

  // Suppliers
  document.getElementById('addSupplierBtn').addEventListener('click', openSupplierModal);
  document.getElementById('closeSupplierModal').addEventListener('click', closeSupplierModal);
  document.getElementById('cancelSupplierBtn').addEventListener('click', closeSupplierModal);
  document.getElementById('supplierForm').addEventListener('submit', handleSupplierSubmit);

  // Permissions
  document.getElementById('userSelect').addEventListener('change', loadUserPermissions);

  // System settings
  document.getElementById('themeSelect').addEventListener('change', (e) => {
    if (e.target.value === 'dark') {
      darkMode.enable();
    } else {
      darkMode.disable();
    }
  });

  document.getElementById('languageSelect').addEventListener('change', (e) => {
    i18n.setLanguage(e.target.value);
  });

  document.getElementById('saveSettingsBtn').addEventListener('click', saveSystemSettings);
  document.getElementById('backupBtn').addEventListener('click', backupDatabase);
  document.getElementById('clearCacheBtn').addEventListener('click', clearCache);

  // Modal outside click
  ['userModal', 'categoryModal', 'supplierModal'].forEach(modalId => {
    document.getElementById(modalId).addEventListener('click', (e) => {
      if (e.target.id === modalId) {
        ui.hideModal(modalId);
      }
    });
  });
}

function switchTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
  document.getElementById(tabName).classList.add('active');
}

async function loadAllData() {
  try {
    ui.showAlert('Loading data...', 'info');

    await Promise.all([
      loadUsers(),
      loadCategories(),
      loadSuppliers()
    ]);

    ui.showAlert('Data loaded successfully', 'success');
  } catch (error) {
    console.error('Load data error:', error);
    ui.showAlert('Failed to load data', 'error');
  }
}

async function loadUsers() {
  try {
    const response = await api.get('/users');
    users = response.data || [];
    renderUsersTable();
    updateUserSelect();
  } catch (error) {
    console.error('Load users error:', error);
  }
}

function renderUsersTable() {
  const tbody = document.getElementById('usersTable');

  if (users.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No users found</td></tr>';
    return;
  }

  tbody.innerHTML = users.map(user => {
    const statusClass = user.is_active ? 'status-active' : 'status-inactive';
    const statusText = user.is_active ? 'Active' : 'Inactive';
    const roleClass = user.role === 'admin' ? 'role-admin' : 'role-worker';

    return `
      <tr>
        <td><strong>${escapeHtml(user.full_name)}</strong></td>
        <td>${escapeHtml(user.email)}</td>
        <td><span class="role-badge ${roleClass}">${user.role}</span></td>
        <td><span class="status-badge ${statusClass}">${statusText}</span></td>
        <td>${ui.formatDate(user.created_at)}</td>
        <td>
          <div class="action-btns">
            ${user.role === 'worker' ? `
              <button class="btn btn-sm btn-info" onclick="managePermissions(${user.id})" title="Permissions">
                <i class="fas fa-shield-alt"></i>
              </button>
            ` : ''}
            <button class="btn btn-sm btn-${user.is_active ? 'warning' : 'success'}" 
                    onclick="toggleUserStatus(${user.id}, ${!user.is_active})"
                    title="${user.is_active ? 'Deactivate' : 'Activate'}">
              <i class="fas fa-${user.is_active ? 'ban' : 'check'}"></i>
            </button>
            <button class="btn btn-sm btn-secondary" onclick="resetPassword(${user.id})" title="Reset Password">
              <i class="fas fa-key"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function updateUserSelect() {
  const select = document.getElementById('userSelect');
  select.innerHTML = '<option value="">Select a user...</option>' +
    users.filter(u => u.role === 'worker').map(user => 
      `<option value="${user.id}">${escapeHtml(user.full_name)} (${user.email})</option>`
    ).join('');
}

async function loadCategories() {
  try {
    const response = await api.get('/categories');
    categories = response.data || [];
    renderCategoriesTable();
  } catch (error) {
    console.error('Load categories error:', error);
  }
}

function renderCategoriesTable() {
  const tbody = document.getElementById('categoriesTable');

  if (categories.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No categories found</td></tr>';
    return;
  }

  tbody.innerHTML = categories.map(category => `
    <tr>
      <td><strong>${escapeHtml(category.name)}</strong></td>
      <td>${escapeHtml(category.description || 'N/A')}</td>
      <td>${ui.formatDate(category.created_at)}</td>
      <td>
        <button class="btn btn-sm btn-info" onclick="editCategory(${category.id})" title="Edit">
          <i class="fas fa-edit"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

async function loadSuppliers() {
  try {
    const response = await api.get('/suppliers');
    suppliers = response.data || [];
    renderSuppliersTable();
  } catch (error) {
    console.error('Load suppliers error:', error);
  }
}

function renderSuppliersTable() {
  const tbody = document.getElementById('suppliersTable');

  if (suppliers.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No suppliers found</td></tr>';
    return;
  }

  tbody.innerHTML = suppliers.map(supplier => {
    const statusClass = supplier.is_active ? 'status-active' : 'status-inactive';
    const statusText = supplier.is_active ? 'Active' : 'Inactive';

    return `
      <tr>
        <td><strong>${escapeHtml(supplier.name)}</strong></td>
        <td>${escapeHtml(supplier.contact_person || 'N/A')}</td>
        <td>${escapeHtml(supplier.phone || 'N/A')}</td>
        <td>${escapeHtml(supplier.email || 'N/A')}</td>
        <td><span class="status-badge ${statusClass}">${statusText}</span></td>
        <td>
          <div class="action-btns">
            <button class="btn btn-sm btn-info" onclick="editSupplier(${supplier.id})" title="Edit">
              <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-sm btn-${supplier.is_active ? 'warning' : 'success'}" 
                    onclick="toggleSupplierStatus(${supplier.id}, ${!supplier.is_active})"
                    title="${supplier.is_active ? 'Deactivate' : 'Activate'}">
              <i class="fas fa-${supplier.is_active ? 'ban' : 'check'}"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

// User Management Functions
function openUserModal() {
  document.getElementById('userForm').reset();
  document.getElementById('userId').value = '';
  document.getElementById('userModalTitle').textContent = 'Add User';
  ui.showModal('userModal');
}

function closeUserModal() {
  ui.hideModal('userModal');
}

async function handleUserSubmit(e) {
  e.preventDefault();

  const formData = {
    email: document.getElementById('email').value,
    password: document.getElementById('password').value,
    fullName: document.getElementById('fullName').value,
    phone: document.getElementById('phone').value
  };

  try {
    await api.post('/auth/register', formData);
    ui.showAlert('User created successfully', 'success');
    closeUserModal();
    await loadUsers();
  } catch (error) {
    ui.showAlert(error.message || 'Failed to create user', 'error');
  }
}

window.toggleUserStatus = async function(userId, activate) {
  try {
    await api.patch(`/users/${userId}/status`, { is_active: activate });
    ui.showAlert(`User ${activate ? 'activated' : 'deactivated'} successfully`, 'success');
    await loadUsers();
  } catch (error) {
    ui.showAlert('Failed to update user status', 'error');
  }
};

window.resetPassword = async function(userId) {
  const newPassword = prompt('Enter new password (min 8 chars, must include uppercase, lowercase, number, symbol):');
  
  if (!newPassword) return;

  if (!ui.isValidPassword(newPassword)) {
    ui.showAlert('Password does not meet requirements', 'error');
    return;
  }

  try {
    await api.post(`/users/${userId}/reset-password`, { newPassword });
    ui.showAlert('Password reset successfully', 'success');
  } catch (error) {
    ui.showAlert('Failed to reset password', 'error');
  }
};

window.managePermissions = function(userId) {
  document.getElementById('userSelect').value = userId;
  loadUserPermissions();
  switchTab('permissions');
};

async function loadUserPermissions() {
  const userId = document.getElementById('userSelect').value;
  
  if (!userId) {
    document.getElementById('permissionsContent').innerHTML = '<p class="text-muted">Select a user to manage permissions</p>';
    return;
  }

  try {
    const response = await api.get(`/users/${userId}/permissions`);
    const permissions = response.data || [];
    renderPermissions(userId, permissions);
  } catch (error) {
    console.error('Load permissions error:', error);
    ui.showAlert('Failed to load permissions', 'error');
  }
}

function renderPermissions(userId, permissions) {
  const modules = ['dashboard', 'stock', 'inventory', 'sales', 'reports', 'customers', 'suppliers'];
  
  const permissionsMap = {};
  permissions.forEach(p => {
    permissionsMap[p.module] = p;
  });

  const html = modules.map(module => {
    const perm = permissionsMap[module] || {};
    const isActive = perm.can_read || perm.can_write;

    return `
      <div class="permission-card ${isActive ? 'active' : ''}">
        <h4>
          <i class="fas fa-${getModuleIcon(module)}"></i>
          ${module.charAt(0).toUpperCase() + module.slice(1)}
        </h4>
        <div class="permission-options">
          <div class="permission-option">
            <input type="checkbox" id="read_${module}" 
                   ${perm.can_read ? 'checked' : ''}
                   onchange="updatePermission(${userId}, '${module}', 'read', this.checked)">
            <label for="read_${module}">Read Access</label>
          </div>
          <div class="permission-option">
            <input type="checkbox" id="write_${module}" 
                   ${perm.can_write ? 'checked' : ''}
                   onchange="updatePermission(${userId}, '${module}', 'write', this.checked)">
            <label for="write_${module}">Write Access</label>
          </div>
        </div>
        ${perm.expires_at ? `
          <div class="expiry-date">
            <small class="text-muted">Expires: ${ui.formatDate(perm.expires_at)}</small>
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  document.getElementById('permissionsContent').innerHTML = html;
}

function getModuleIcon(module) {
  const icons = {
    dashboard: 'home',
    stock: 'boxes',
    inventory: 'chart-pie',
    sales: 'shopping-cart',
    reports: 'file-alt',
    customers: 'users',
    suppliers: 'truck'
  };
  return icons[module] || 'cog';
}

window.updatePermission = async function(userId, module, type, enabled) {
  try {
    // Get current permissions for this module
    const response = await api.get(`/users/${userId}/permissions`);
    const permissions = response.data || [];
    const currentPerm = permissions.find(p => p.module === module) || {};

    // Update permission
    const permData = {
      module,
      can_read: type === 'read' ? enabled : (currentPerm.can_read || false),
      can_write: type === 'write' ? enabled : (currentPerm.can_write || false)
    };

    await api.post(`/users/${userId}/permissions`, permData);
    ui.showAlert('Permission updated successfully', 'success');
    await loadUserPermissions();
  } catch (error) {
    ui.showAlert('Failed to update permission', 'error');
    await loadUserPermissions(); // Reload to reset checkboxes
  }
};

// Category Management
function openCategoryModal() {
  document.getElementById('categoryForm').reset();
  ui.showModal('categoryModal');
}

function closeCategoryModal() {
  ui.hideModal('categoryModal');
}

async function handleCategorySubmit(e) {
  e.preventDefault();

  const formData = {
    name: document.getElementById('categoryName').value,
    description: document.getElementById('categoryDesc').value
  };

  try {
    await api.post('/categories', formData);
    ui.showAlert('Category created successfully', 'success');
    closeCategoryModal();
    await loadCategories();
  } catch (error) {
    ui.showAlert(error.message || 'Failed to create category', 'error');
  }
}

window.editCategory = function(categoryId) {
  ui.showAlert('Edit category feature coming soon', 'info');
};

// Supplier Management
function openSupplierModal() {
  document.getElementById('supplierForm').reset();
  ui.showModal('supplierModal');
}

function closeSupplierModal() {
  ui.hideModal('supplierModal');
}

async function handleSupplierSubmit(e) {
  e.preventDefault();

  const formData = {
    name: document.getElementById('supplierName').value,
    contact_person: document.getElementById('contactPerson').value,
    phone: document.getElementById('supplierPhone').value,
    email: document.getElementById('supplierEmail').value,
    address: document.getElementById('supplierAddress').value
  };

  try {
    await api.post('/suppliers', formData);
    ui.showAlert('Supplier created successfully', 'success');
    closeSupplierModal();
    await loadSuppliers();
  } catch (error) {
    ui.showAlert(error.message || 'Failed to create supplier', 'error');
  }
}

window.editSupplier = function(supplierId) {
  ui.showAlert('Edit supplier feature coming soon', 'info');
};

window.toggleSupplierStatus = async function(supplierId, activate) {
  try {
    await api.put(`/suppliers/${supplierId}`, { is_active: activate });
    ui.showAlert(`Supplier ${activate ? 'activated' : 'deactivated'} successfully`, 'success');
    await loadSuppliers();
  } catch (error) {
    ui.showAlert('Failed to update supplier status', 'error');
  }
};

// System Settings
function saveSystemSettings() {
  ui.showAlert('System settings saved successfully', 'success');
}

function backupDatabase() {
  if (confirm('Create a database backup? This may take a few moments.')) {
    ui.showAlert('Database backup feature coming soon', 'info');
  }
}

function clearCache() {
  if (confirm('Clear all cached data? This will log you out.')) {
    localStorage.clear();
    sessionStorage.clear();
    ui.showAlert('Cache cleared. Redirecting to login...', 'success');
    setTimeout(() => {
      window.location.href = '/login.html';
    }, 2000);
  }
}

function escapeHtml(text) {
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return String(text || '').replace(/[&<>"']/g, m => map[m]);
}
